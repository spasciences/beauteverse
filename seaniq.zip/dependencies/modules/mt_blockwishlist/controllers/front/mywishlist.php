<?php
/**
 * Copyright since 2007 PrestaShop SA and Contributors
 * PrestaShop is an International Registered Trademark & Property of PrestaShop SA
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to https://devdocs.prestashop.com/ for more information.
 *
 * @author    PrestaShop SA and Contributors <contact@prestashop.com>
 * @copyright Since 2007 PrestaShop SA and Contributors
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */

/**
 * @since 1.5.0
 */
class Mt_BlockWishListMyWishListModuleFrontController extends ModuleFrontController
{
	public $ssl = true;

	public function __construct()
	{
		parent::__construct();
		$this->context = Context::getContext();
		include_once($this->module->getLocalPath().'WishList.php');
	}

	/**
	 * @see FrontController::initContent()
	 */
	public function initContent()
	{
		parent::initContent();
		$action = Tools::getValue('action');

		if (!Tools::isSubmit('myajax'))
			$this->assign();
		elseif (!empty($action) && method_exists($this, 'ajaxProcess'.Tools::toCamelCase($action)))
			$this->{'ajaxProcess'.Tools::toCamelCase($action)}();
		else
			die(Tools::jsonEncode(array('error' => 'method doesn\'t exist')));
	}

	/**
	 * Assign wishlist template
	 */
	public function assign()
	{

		$errors = array();

		if ($this->context->customer->isLogged())
		{
			$add = Tools::getIsset('add');
			$add = (empty($add) === false ? 1 : 0);
			$delete = Tools::getIsset('deleted');
			$delete = (empty($delete) === false ? 1 : 0);
			$default = Tools::getIsset('default');
			$default = (empty($default) === false ? 1 : 0);
			$id_wishlist = Tools::getValue('id_wishlist');
			if (Tools::isSubmit('submitWishlist'))
			{
				if (Configuration::get('PS_TOKEN_ACTIVATED') == 1 && strcmp(Tools::getToken(), Tools::getValue('token')))
					$errors[] = $this->module->l('Invalid token', 'mywishlist');
				if (!count($errors))
				{
					$name = Tools::getValue('name');
					if (empty($name))
						$errors[] = $this->module->l('You must specify a name.', 'mywishlist');
					if (WishList::isExistsByNameForUser($name))
						$errors[] = $this->module->l('This name is already used by another list.', 'mywishlist');

					if (!count($errors))
					{
						$wishlist = new WishList();
						$wishlist->id_shop = $this->context->shop->id;
						$wishlist->id_shop_group = $this->context->shop->id_shop_group;
						$wishlist->name = $name;
						$wishlist->id_customer = (int)$this->context->customer->id;
						!$wishlist->isDefault($wishlist->id_customer) ? $wishlist->default = 1 : '';
						list($us, $s) = explode(' ', microtime());
						srand($s * $us);
						$wishlist->token = Tools::strtoupper(Tools::substr(sha1(uniqid(rand(), true)._COOKIE_KEY_.$this->context->customer->id), 0, 16));
						$wishlist->add();

						Tools::redirect($this->context->link->getModuleLink('mt_blockwishlist', 'mywishlist'));
					}
				}
			}
			else if ($add)
				WishList::addCardToWishlist($this->context->customer->id, Tools::getValue('id_wishlist'), $this->context->language->id);
			elseif ($delete && empty($id_wishlist) === false)
			{
				$wishlist = new WishList((int)$id_wishlist);
				if ($this->context->customer->isLogged() && $this->context->customer->id == $wishlist->id_customer && Validate::isLoadedObject($wishlist))
					$wishlist->delete();
				else
					$errors[] = $this->module->l('Cannot delete this wishlist', 'mywishlist');
			}
			elseif ($default)
			{
				$wishlist = new WishList((int)$id_wishlist);
				if ($this->context->customer->isLogged() && $this->context->customer->id == $wishlist->id_customer && Validate::isLoadedObject($wishlist))
					$wishlist->setDefault();
				else
					$errors[] = $this->module->l('Cannot delete this wishlist', 'mywishlist');
			}
			$this->context->smarty->assign('wishlists', WishList::getByIdCustomer($this->context->customer->id));
			$this->context->smarty->assign('nbProducts', WishList::getInfosByIdCustomer($this->context->customer->id));
		}
		else
			Tools::redirect('index.php?controller=authentication&back='.urlencode($this->context->link->getModuleLink('mt_blockwishlist', 'mywishlist')));

		$this->context->smarty->assign(array(
			'id_customer' => (int)$this->context->customer->id,
			'errors' => $errors,
			'form_link' => $errors,
		));

		$this->setTemplate('module:mt_blockwishlist/views/templates/front/mywishlist.tpl');

	}

	public function ajaxProcessDeleteList()
	{
		if (!$this->context->customer->isLogged())
			die(Tools::jsonEncode(array('success' => false,
				'error' => $this->module->l('You aren\'t logged in', 'mywishlist'))));
		$default = Tools::getIsset('default');
		$default = (empty($default) === false ? 1 : 0);
		$id_wishlist = Tools::getValue('id_wishlist');
		$wishlist = new WishList((int)$id_wishlist);
		if (Validate::isLoadedObject($wishlist) && $wishlist->id_customer == $this->context->customer->id)
		{
			$default_change = $wishlist->default ? true : false;
			$id_customer = $wishlist->id_customer;
			$wishlist->delete();
		}
		else
			die(Tools::jsonEncode(array('success' => false,
				'error' => $this->module->l('Cannot delete this wishlist', 'mywishlist'))));
		if ($default_change)
		{
			$array = WishList::getDefault($id_customer);

			if (count($array))
				die(Tools::jsonEncode(array(
					'success' => true,
					'id_default' => $array[0]['id_wishlist']
					)));
		}
		die(Tools::jsonEncode(array('success' => true)));
	}

	public function ajaxProcessSetDefault()
	{
		if (!$this->context->customer->isLogged())
			die(Tools::jsonEncode(array('success' => false,
				'error' => $this->module->l('You aren\'t logged in', 'mywishlist'))));
		$default = Tools::getIsset('default');
		$default = (empty($default) === false ? 1 : 0);
		$id_wishlist = Tools::getValue('id_wishlist');

		if ($default)
		{
			$wishlist = new WishList((int)$id_wishlist);
			if (Validate::isLoadedObject($wishlist) && $wishlist->id_customer == $this->context->customer->id && $wishlist->setDefault())
				die(Tools::jsonEncode(array('success' => true)));
		}
		die(Tools::jsonEncode(array('error' => true)));
	}
}
