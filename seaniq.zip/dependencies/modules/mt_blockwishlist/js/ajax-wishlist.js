//global variables
var wishlistProductsIds = [];
$(document).ready(function(){
	wishlistRefreshStatus();

	$(document).on('change', 'select[name=wishlists]', function(){
		WishlistChangeDefault('wishlist_block_list', $(this).val());
	});	
});

function Wishlist_click() {
    $(".wishlist_button").popover({
        html: true,
        content: function () {
            return $("#popover-content").html();
        }
    });

    $('.wishlist').each(function () {
        current = $(this);
        $(this).children('.wishlist_button_list').popover({
            html: true,
            content: function () {
                return current.children('.popover-content').html();
            }
        });
    });
}

function ShowModalWishList(status) {
    $(".PopupWishList").remove();
    var html = "";
    html += '<div class="PopupWishList">';
    html += '<div class="PopupWishListInner">';
    if (status == 1) {
        html += '<h4 class="head-title"><i class="material-icons">&#xE834;</i>"' + wishlist_title_success + '"<span class="close-popcompare"><i class="material-icons">&#xE5C9;</i></span></h4>';
        html += '<div class="noty_text_body">';
        html += '<p>';
        html += added_to_wishlist;
        html += '</p>';
        html += '<a class="btn btn-primary" href="' + mywishlist_url + '">' + wishlist_button + '</a>';        
        html += '</div>';
    } else if (status == 0) {
        html += '<h4 class="head-title"><i class="material-icons">&#xE160;</i>"' + wishlist_title_error + '"<span class="close-popcompare"><i class="material-icons">&#xE5C9;</i></span></h4>';
        html += '<div class="noty_text_body" style="color: #f00;">';
        html += '<p>';
        html += loggin_required;
        html += '</p>';
        html += '<a class="btn btn-primary" href="' + myaccout_url + '">' + wishlist_button_login + '</a>';
        html += '</div>';
    }
    html += '</div>';
    html += '</div>';
    $(html).appendTo("body");
    $(".close-popcompare").click(function () {
        $(".PopupWishList").remove();
    });
    setTimeout(function () {
        $(".PopupWishList").remove();
    }, 5000);
}

const mt_process_products = {}
function WishlistCart(id, action, id_product, id_product_attribute, quantity, id_wishlist)
{
	if (!mt_process_products[id_product]) {
		mt_process_products[id_product] = true
		$.ajax({
			type: 'GET',
			url: baseDir + 'modules/mt_blockwishlist/cart.php?rand=' + new Date().getTime(),
			headers: { "cache-control": "no-cache" },
			async: true,
			cache: false,
			data: 'action=' + action + '&id_product=' + id_product + '&quantity=' + quantity + '&token=' + static_token + '&id_product_attribute=' + id_product_attribute + '&id_wishlist=' + id_wishlist,
			success: function(data)
			{
				delete mt_process_products[id_product]
				if (action == 'add')
				{
					if (isLogged == true) {
						wishlistProductsIdsAdd(id_product);
						wishlistRefreshStatus();

						$('.wishtlist_top .cart-wishlist-number').html(data);
	                    setTimeout(function () {
	                        ShowModalWishList(1);
	                    }, 300);					
					}else{
						setTimeout(function () {
	                        ShowModalWishList(0);
	                    }, 300);
					}
				}
				if (action == 'delete') {
					wishlistProductsIdsRemove(id_product);
					wishlistRefreshStatus();
				}
				if($('#' + id).length != 0)
				{
					$('#' + id).slideUp('normal');
					document.getElementById(id).innerHTML = data;
					$('#' + id).slideDown('normal');
				}
			}
		});
	}
	else {
		console.log('add to wishlist in progress')
	}
	
}

/**
* Change customer default wishlist
*
* @return void
*/
function WishlistChangeDefault(id, id_wishlist)
{
	$.ajax({
		type: 'GET',
		url: baseDir + 'modules/mt_blockwishlist/cart.php?rand=' + new Date().getTime(),
		headers: { "cache-control": "no-cache" },
		async: true,
		data: 'id_wishlist=' + id_wishlist + '&token=' + static_token,
		cache: false,
		success: function(data)
		{
			$('#' + id).slideUp('normal');
			document.getElementById(id).innerHTML = data;
			$('#' + id).slideDown('normal');
		}
	});
}

/**
* Delete wishlist
*
* @return boolean succeed
*/
function WishlistDelete(id, id_wishlist, msg)
{
	var res = confirm(msg);
	if (res == false)
		return (false);

	if (typeof mywishlist_url == 'undefined')
		return (false);

	$.ajax({
		type: 'GET',
		async: true,
		dataType: "json",
		url: mywishlist_url,
		headers: { "cache-control": "no-cache" },
		cache: false,
		data: {
			rand: new Date().getTime(),
			deleted: 1,
			myajax: 1,
			id_wishlist: id_wishlist,
			action: 'deletelist'
		},
		success: function(data)
		{
			var mywishlist_siblings_count = $('#' + id).siblings().length;
			$('#' + id).fadeOut('slow').remove();
			$("#block-order-detail").html('');
			if (mywishlist_siblings_count == 0)
				$("#block-history").remove();

			if (data.id_default)
			{
				var td_default = $("#wishlist_"+data.id_default+" > .wishlist_default");
				$("#wishlist_"+data.id_default+" > .wishlist_default > a").remove();
				td_default.append('<p class="is_wish_list_default"><i class="icon icon-check-square"></i></p>');
			}
		}
	});
}

function WishlistDefault(id, id_wishlist)
{
	if (typeof mywishlist_url == 'undefined')
		return (false);

	$.ajax({
		type: 'GET',
		async: true,
		url: mywishlist_url,
		headers: { "cache-control": "no-cache" },
		cache: false,
		data: {
			rand:new Date().getTime(),
			'default': 1,
			id_wishlist:id_wishlist,
			myajax: 1,
			action: 'setdefault'
		},
		success: function (data)
		{
			var old_default_id = $(".is_wish_list_default").parents("tr").attr("id");
			var td_check = $(".is_wish_list_default").parent();
			$(".is_wish_list_default").remove();
			td_check.append('<a href="#" onclick="javascript:event.preventDefault();(WishlistDefault(\''+old_default_id+'\', \''+old_default_id.replace("wishlist_", "")+'\'));"><i class="icon icon-square"></i></a>');
			var td_default = $("#"+id+" > .wishlist_default");
			$("#"+id+" > .wishlist_default > a").remove();
			td_default.append('<p class="is_wish_list_default"><i class="icon icon-check-square"></i></p>');
		}
	});
}


function wishlistProductsIdsAdd(id)
{
	if ($.inArray(parseInt(id),wishlistProductsIds) == -1)
		wishlistProductsIds.push(parseInt(id))
}

function wishlistProductsIdsRemove(id)
{
	wishlistProductsIds.splice($.inArray(parseInt(id),wishlistProductsIds), 1)
}

function wishlistRefreshStatus()
{
	$('.addToWishlist').each(function(){
		if ($.inArray(parseInt($(this).data('id-product')),wishlistProductsIds)!= -1)
			$(this).addClass('checked');
		else
			$(this).removeClass('checked');
	});
}


