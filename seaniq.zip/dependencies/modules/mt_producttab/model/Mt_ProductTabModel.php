<?php

class Mt_ProductTabModel extends ObjectModel
{
    public $id_mt_producttab;
    public $active = 1;
    public $position;
    public $tab_type;
    public $tab_content;

    //Multilang Fields
    public $title;

    /**
     * @see ObjectModel::$definition
     */
    public static $definition = array(
        'table' => 'mt_producttab',
        'primary' => 'id_mt_producttab',
        'multilang' => true,
        'fields' => array(
            //Fields
            'active'          =>  array('type' => self::TYPE_INT, 'validate' => 'isBool'),
            'position'        =>  array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'),
            'tab_type'        =>  array('type' => self::TYPE_STRING),
            'tab_content'     =>  array('type' => self::TYPE_STRING),

            //Multilanguage Fields
            'title'           =>  array('type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isGenericName', 'required' => true, 'size' => 250)
        )
    );

    /*-------------------------------------------------------------*/
    /*  CONSTRUCT
    /*-------------------------------------------------------------*/
    public function __construct($id_mt_producttab = null, $id_lang = null, $id_shop = null)
    {
        Shop::addTableAssociation('mt_producttab', array('type' => 'shop'));
        parent::__construct($id_mt_producttab, $id_lang, $id_shop);
    }

    /*-------------------------------------------------------------*/
    /*  ADD
    /*-------------------------------------------------------------*/
    public function add($autoddate = true, $null_values = false)
    {
        $this->position = (int) $this->getMaxPosition() + 1;
        return parent::add();
    }

    /*-------------------------------------------------------------*/
    /*  DELETE
    /*-------------------------------------------------------------*/
    public function delete()
    {
        $response = parent::delete();
        $this->reorderTabs();

        return $response;
    }

    /*-------------------------------------------------------------*/
    /*  GET ALL ROWS
    /*-------------------------------------------------------------*/
    public static function getAll()
	{
		$response = Db::getInstance()->executeS('
            SELECT *
			FROM `'._DB_PREFIX_.'mt_producttab`'
        );
        
        return $response;
	}

    /*-------------------------------------------------------------*/
    /*  GET TAB IDs
    /*-------------------------------------------------------------*/
    public function getTabIds($id_shop)
    {
        $response = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('
            SELECT a.id_mt_producttab, b.id_mt_producttab
            FROM '._DB_PREFIX_.'mt_producttab as a,
                 '._DB_PREFIX_.'mt_producttab_shop as b
            WHERE a.id_mt_producttab = b.id_mt_producttab
            AND b.id_shop = '.$id_shop.'
            AND a.active = 1
            ORDER BY a.position ASC'
        );

        return $response;
    }

    /*-------------------------------------------------------------*/
    /*  GET MAX POSITION
    /*-------------------------------------------------------------*/
    public static function getMaxPosition()
    {
        $response = Db::getInstance()->getRow('
            SELECT MAX(position)
			FROM `'._DB_PREFIX_.'mt_producttab`'
        );

        if ($response['MAX(position)'] == null){
            return -1;
        }

        return $response['MAX(position)'];

    }

    /*-------------------------------------------------------------*/
    /*  UPDATE POSITION
    /*-------------------------------------------------------------*/
    public function updatePosition($way, $position)
    {
        if (!$tabs = Db::getInstance()->executeS('
			SELECT `id_mt_producttab`, `position`
			FROM `'._DB_PREFIX_.'mt_producttab`
			ORDER BY `position` ASC'
        ))
            return false;

        foreach ($tabs as $tab)
            if ((int)$tab['id_mt_producttab'] == (int)$this->id)
                $moved_tab = $tab;

        if (!isset($moved_tab) || !isset($position))
            return false;

        return (Db::getInstance()->execute('
			UPDATE `'._DB_PREFIX_.'mt_producttab`
			SET `position`= `position` '.($way ? '- 1' : '+ 1').'
			WHERE `position`
			'.($way
                       ? '> '.(int)$moved_tab['position'].' AND `position` <= '.(int)$position
                       : '< '.(int)$moved_tab['position'].' AND `position` >= '.(int)$position
			))
            && Db::getInstance()->execute('
			UPDATE `'._DB_PREFIX_.'mt_producttab`
			SET `position` = '.(int)$position.'
			WHERE `id_mt_producttab` = '.(int)$moved_tab['id_mt_producttab']));
    }

    /*-------------------------------------------------------------*/
    /*  REORDER TABS AFTER DELETION
    /*-------------------------------------------------------------*/
    public static function reorderTabs()
    {
        $return = true;

        $sql = 'SELECT `id_mt_producttab`
		        FROM `'._DB_PREFIX_.'mt_producttab`
		        ORDER BY `position` ASC';

        $result = Db::getInstance()->executeS($sql);

        $i = 0;
        foreach ($result as $value) {
            $return = Db::getInstance()->execute('
			UPDATE `'._DB_PREFIX_.'mt_producttab`
			SET `position` = '.(int)$i++.'
			WHERE `id_mt_producttab` = '.(int)$value['id_mt_producttab']);
        }

        return $return;
    }
}