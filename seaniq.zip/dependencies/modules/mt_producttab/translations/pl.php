<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mt_producttab}prestashop>mt_producttab_ab1744ecf933bab5dced87771e943a67'] = 'Popularne produkty';
