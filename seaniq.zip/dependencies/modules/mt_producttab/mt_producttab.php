<?php
/**
 * Copyright since 2007 PrestaShop SA and Contributors
 * PrestaShop is an International Registered Trademark & Property of PrestaShop SA
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to https://devdocs.prestashop.com/ for more information.
 *
 * @author    PrestaShop SA and Contributors <contact@prestashop.com>
 * @copyright Since 2007 PrestaShop SA and Contributors
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\PrestaShop\Core\Module\WidgetInterface;
use PrestaShop\PrestaShop\Adapter\Category\CategoryProductSearchProvider;
use PrestaShop\PrestaShop\Adapter\Image\ImageRetriever;
use PrestaShop\PrestaShop\Adapter\Product\PriceFormatter;
use PrestaShop\PrestaShop\Core\Product\ProductListingPresenter;
use PrestaShop\PrestaShop\Adapter\Product\ProductColorsRetriever;
use PrestaShop\PrestaShop\Core\Product\Search\ProductSearchContext;
use PrestaShop\PrestaShop\Core\Product\Search\ProductSearchQuery;
use PrestaShop\PrestaShop\Core\Product\Search\SortOrder;
use PrestaShop\PrestaShop\Core\Addon\Module\ModuleManagerBuilder;
use Symfony\Component\HttpKernel\HttpKernelInterface;

include_once(_PS_MODULE_DIR_.'mt_producttab/model/Mt_ProductTabModel.php');


class Mt_ProductTab extends Module implements WidgetInterface
{

    private $_html = '';
    private $_output = '';

    public function __construct()
    {
        $this->name = 'mt_producttab';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'Mahardhi';

        $this->bootstrap = true;
        parent::__construct();

        $this->displayName = $this->trans('Product Tab', array(), 'Modules.ProductTab.Admin');
        $this->description = $this->trans('Displays product tab on homepage.', array(), 'Modules.ProductTab.Admin');
        $this->ps_versions_compliancy = array('min' => '1.7.4.0', 'max' => _PS_VERSION_);

    }

    /**
     * @see Module::install()
     */
    public function install()
    {
        if (Shop::isFeatureActive()) {
            Shop::setContext(Shop::CONTEXT_ALL);
        }

        return parent::install() &&
              $this->registerHook('displayHeader') &&
              $this->registerHook('displayHome') &&
              $this->registerHook('actionShopDataDuplication') &&
              $this->registerHook('displayBackOfficeHeader') &&
              $this->_createTables() &&
              $this->_createConfigs() &&
              $this->_installDemoData() &&
              $this->_createTab();
    }

    /**
     * Adds samples
     */
    private function _createTables()
    {
        $return = (bool) Db::getInstance()->execute('
            CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'mt_producttab` (
                `id_mt_producttab` int(10) unsigned NOT NULL AUTO_INCREMENT,
                `active` tinyint(1) unsigned NOT NULL,
                `position` int(5) unsigned NOT NULL,
                `tab_type` varchar(255) NOT NULL,
                `tab_content` text NOT NULL,
                PRIMARY KEY (`id_mt_producttab`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=UTF8;
        ');

        $return &= Db::getInstance()->execute('
            CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'mt_producttab_lang` (
                `id_mt_producttab` int(10) unsigned NOT NULL,
                `id_lang` int(10) unsigned NOT NULL,
                `title` varchar(255) NOT NULL,
                PRIMARY KEY (`id_mt_producttab`,`id_lang`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=UTF8;
        ');

        $return &= Db::getInstance()->execute('
            CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'mt_producttab_shop` (
                `id_mt_producttab` int(10) unsigned NOT NULL,
                `id_shop` int(10) unsigned NOT NULL,
                PRIMARY KEY (`id_mt_producttab`,`id_shop`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=UTF8;
        ');

        return $return;
    }

    /**
     * @see Module::uninstall()
     */
    public function uninstall()
    {
        return parent::uninstall() &&
               $this->unregisterHook('actionShopDataDuplication') &&
               $this->_deleteTables() &&
               $this->_deleteConfigs() &&
               $this->_deleteTab();
    }

    /**
     * delete tables
     */
    private function _deleteTables() {
        return Db::getInstance()->execute('
                DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'mt_producttab`, `' . _DB_PREFIX_ . 'mt_producttab_lang`, `' . _DB_PREFIX_ . 'mt_producttab_shop`;
        ');
    }

    /**
     * _createConfigs
     */
    private function _createConfigs() {
        $return = Configuration::updateValue($this->name . '_nb_products', 20);
        $return &= Configuration::updateValue($this->name . '_DISABLESHOWALL', 0);
        $return &= Configuration::updateValue($this->name . '_order_way', 0);
        $return &= Configuration::updateValue($this->name . '_order_by', 0);

        return $return;
    }
    /**
     * _deleteConfigs
     */
    private function _deleteConfigs() {
        $return = Configuration::deleteByName($this->name . '_nb_products');
        $return &= Configuration::deleteByName($this->name . '_DISABLESHOWALL');
        $return &= Configuration::deleteByName($this->name . '_order_way');
        $return &= Configuration::deleteByName($this->name . '_order_by');

        return $return;
    }
    /**
     * _installDemoData
     */
    private function _installDemoData() {
        $languages = $this->context->language->getLanguages(true);

        // Featured Products
        $ProductTab = new Mt_ProductTabModel();
        foreach ($languages as $language) {
            $ProductTab->title[$language['id_lang']] = $this->trans('Featured', array(), 'Modules.ProductTab.Admin');
        }
        $ProductTab->tab_type = 'featured';
        $ProductTab->add();

        // latest Products
        $ProductTab = new Mt_ProductTabModel();
        foreach ($languages as $language) {
            $ProductTab->title[$language['id_lang']] = $this->trans('Latest', array(), 'Modules.ProductTab.Admin');
        }
        $ProductTab->tab_type = 'new';
        $ProductTab->add();
        
        // bestseller Products
        $ProductTab = new Mt_ProductTabModel();
        foreach ($languages as $language) {
            $ProductTab->title[$language['id_lang']] = $this->trans('Bestseller', array(), 'Modules.ProductTab.Admin');
        }
        $ProductTab->tab_type = 'bestseller';
        $ProductTab->add();

        return true;
    }
    /**
     * _createTab
     */
    private function _createTab() {
        $return = true;

        // First check for parent tab
        $parentTabID = Tab::getIdFromClassName('AdminTabMenu');

        if ($parentTabID) {
            $parentTab = new Tab($parentTabID);
        } else {
            $parentTab = new Tab();
            $parentTab->active = 1;
            $parentTab->name = array();
            $parentTab->class_name = "AdminTabMenu";
            foreach (Language::getLanguages() as $lang) {
                $parentTab->name[$lang['id_lang']] = "Mahardhi Themes";
            }
            $parentTab->id_parent = 0;
            $parentTab->module = '';
            $return &= $parentTab->add();
        }
        // Check for parent tab2
        $parentTab_2ID = Tab::getIdFromClassName('AdminTabMenuSecond');
        if ($parentTab_2ID) {
            $parentTab_2 = new Tab($parentTab_2ID);
        } else {
            $parentTab_2 = new Tab();
            $parentTab_2->active = 1;
            $parentTab_2->name = array();
            $parentTab_2->class_name = "AdminTabMenuSecond";
            foreach (Language::getLanguages() as $lang) {
                $parentTab_2->name[$lang['id_lang']] = "Product Tab Configure";
            }
            $parentTab_2->id_parent = $parentTab->id;
            $parentTab_2->module = '';
            $return &= $parentTab_2->add();
        }
        // Created tab
        $tab = new Tab();
        $tab->active = 1;
        $tab->class_name = "AdminTabMenuProduct";
        $tab->name = array();
        foreach (Language::getLanguages() as $lang) {
            $tab->name[$lang['id_lang']] = "Product Tab";
        }
        $tab->id_parent = $parentTab_2->id;
        $tab->module = $this->name;
        $return &= $tab->add();

        return $return;
    }
    /**
     * _deleteTab
     */
    private function _deleteTab() {
        $id_tab = Tab::getIdFromClassName('AdminTabMenuProduct');
        if ($id_tab) {
            $tab = new Tab($id_tab);
            $tab->delete();
        }
        // Get the number of tabs inside our parent tab
        // If there is no tabs, remove the parent
        $parentTab_2ID = Tab::getIdFromClassName('AdminTabMenuSecond');
        if ($parentTab_2ID) {
            $tabCount_2 = Tab::getNbTabs($parentTab_2ID);
            if ($tabCount_2 == 0) {
                $parentTab_2 = new Tab($parentTab_2ID);
                $parentTab_2->delete();
            }
        }
        // Get the number of tabs inside our parent tab
        // If there is no tabs, remove the parent
        $parentTabID = Tab::getIdFromClassName('AdminTabMenu');
        if ($parentTabID) {
            $tabCount = Tab::getNbTabs($parentTabID);
            if ($tabCount == 0) {
                $parentTab = new Tab($parentTabID);
                $parentTab->delete();
            }
        }
        return true;
    }
    /**
     * getContent
     */
    public function getContent() {
        $errors = array();

        if (Tools::isSubmit('submit' . $this->name)) {

            // Validate numeric values
            if (Tools::isSubmit('nb_products')) {
                if (Validate::isInt(Tools::getValue('nb_products'))) {
                    Configuration::updateValue($this->name . '_nb_products', Tools::getValue('nb_products'));
                } else {
                    $errors[] = $this->trans('Max product count per tab must be a numeric value!', array(), 'Modules.ProductTab.Admin');
                }
            }

            if (Tools::isSubmit('mt_producttab_disableshowall')) {
                Configuration::updateValue($this->name . '_DISABLESHOWALL', Tools::getValue('mt_producttab_disableshowall'));
            }

            if (Tools::isSubmit('order_way')) {
                Configuration::updateValue($this->name . '_order_way', Tools::getValue('order_way'));
            }
            if (Tools::isSubmit('order_by')) {
                Configuration::updateValue($this->name . '_order_by', Tools::getValue('order_by'));
            }

            // Prepare the output
            if (count($errors)) {
                $this->_output .= $this->displayError(implode('<br />', $errors));
            } else {
                $this->_output .= $this->displayConfirmation($this->trans('Configuration updated', array(), 'Modules.ProductTab.Admin'));
            }
        }

        if (Tools::getValue('ajax', 'false') != 'false') {
            $query = Tools::getValue('q', false);
            if ( ! $query or $query == '' or Tools::strlen($query) < 1) {
                die();
            }

            if ($pos = strpos($query, ' (ref:')) {
                $query = Tools::substr($query, 0, $pos);
            }

            $excludeIds = Tools::getValue('excludeIds', false);
            if ($excludeIds && $excludeIds != 'NaN') {
                $excludeIds = implode(',', array_map('intval', explode(',', $excludeIds)));
            } else {
                $excludeIds        = '';
                $excludePackItself = Tools::getValue('packItself', false);
            }

            $excludeVirtuals = (bool)Tools::getValue('excludeVirtuals', true);
            $exclude_packs   = (bool)Tools::getValue('exclude_packs', true);

            $context = Context::getContext();

            $sql = 'SELECT p.`id_product`, pl.`link_rewrite`, p.`reference`, pl.`name`, image_shop.`id_image` id_image, il.`legend`, p.`cache_default_attribute`
            FROM `' . _DB_PREFIX_ . 'product` p
            ' . Shop::addSqlAssociation('product', 'p') . '
            LEFT JOIN `' . _DB_PREFIX_ . 'product_lang` pl ON (pl.id_product = p.id_product AND pl.id_lang = ' . (int)$context->language->id . Shop::addSqlRestrictionOnLang('pl') . ')
            LEFT JOIN `' . _DB_PREFIX_ . 'image_shop` image_shop
                ON (image_shop.`id_product` = p.`id_product` AND image_shop.cover=1 AND image_shop.id_shop=' . (int)$context->shop->id . ')
            LEFT JOIN `' . _DB_PREFIX_ . 'image_lang` il ON (image_shop.`id_image` = il.`id_image` AND il.`id_lang` = ' . (int)$context->language->id . ')
            WHERE (pl.name LIKE \'%' . pSQL($query) . '%\' OR p.reference LIKE \'%' . pSQL($query) . '%\')' . (! empty($excludeIds) ? ' AND p.id_product NOT IN (' . $excludeIds . ') ' : ' ') . (! empty($excludePackItself) ? ' AND p.id_product <> ' . $excludePackItself . ' ' : ' ') . ($excludeVirtuals ? 'AND NOT EXISTS (SELECT 1 FROM `' . _DB_PREFIX_ . 'product_download` pd WHERE (pd.id_product = p.id_product))' : '') . ($exclude_packs ? 'AND (p.cache_is_pack IS NULL OR p.cache_is_pack = 0)' : '') . ' GROUP BY p.id_product';

            $items = Db::getInstance()->executeS($sql);

            if ($items && ($excludeIds)) {
                foreach ($items as $item) {
                    $item['name'] = str_replace('|', '&#124;', $item['name']);
                    $item['url'] = Context::getContext()->link->getAdminLink('AdminProducts', true, array('id_product' => $item['id_product']), array('id_product' => $item['id_product']));
                    echo trim($item['name']) . (! empty($item['reference']) ? ' (ref: ' . $item['reference'] . ')' : '') . '|' . (int)($item['id_product']) . '|' . self::getImagesByID($item['link_rewrite'], (int)($item['id_product']))."|".$item['url']."\n";
                }
            }
            die();
        }

        return $this->_output . $this->displayForm();
    }

    public static function getImagesByID($link_rewrite, $id_product) {
        $limit = 1;
        $id_image = Db::getInstance()->ExecuteS('SELECT `id_image` FROM `' . _DB_PREFIX_ . 'image` WHERE cover=1 AND `id_product` = ' . (int)$id_product . ' ORDER BY position ASC LIMIT 0, ' . (int)$limit);
        $toReturn = array();
        if (!$id_image) {
            return;
        }
        else {
            foreach ($id_image as $image)
            {
                $toReturn = Context::getContext()->link->getImageLink($link_rewrite, $id_product . '-' . $image['id_image'], 'small_default');
            }
        }
        return $toReturn;
    }

    /**
     * displayForm
     */
    public function displayForm() {
        // Get default Language
        $id_default_lang = (int) Configuration::get('PS_LANG_DEFAULT');

        $fields_form = array(
            'mt_producttab-general' => array(
                'form' => array(
                    'legend' => array(
                        'title' => $this->trans('Products Tabs Options', array(), 'Modules.ProductTab.Admin'),
                        'icon' => 'icon-cogs'
                    ),
                    'input' => array(

                        array(
                            'type' => 'select',
                            'label' => $this->trans('Order Way', array(), 'Admin.Global'),
                            'class' => 'form-action',
                            'name' => 'order_way',
                            'options' => array(
                                'query' => array(
                                    array('id' => 'asc', 'name' => $this->trans('Asc', array(), 'Admin.Global')),
                                    array('id' => 'desc', 'name' => $this->trans('Desc', array(), 'Admin.Global')),
                                    array('id' => 'random', 'name' => $this->trans('Random', array(), 'Admin.Global'))), // remove to increase speed
                                'id' => 'id',
                                'name' => 'name'
                            ),
                            'default' => 'all'
                        ),
                        array(
                            'type' => 'select',
                            'label' => $this->trans('Order By', array(), 'Admin.Global'),
                            'name' => 'order_by',
                            'options' => array(
                                'query' => array(
                                    array('id' => 'id_product', 'name' => self::l('ID')),
                                    array('id' => 'name', 'name' => self::l('Name')),
                                    array('id' => 'reference', 'name' => self::l('Reference')),
                                    array('id' => 'price', 'name' => self::l('Base price')),
                                    array('id' => 'date_add', 'name' => self::l('Date add')),
                                    array('id' => 'date_upd', 'name' => self::l('Date update'))),
                                'id' => 'id',
                                'name' => 'name'
                            ),
                            'form_group_class' => 'order_type_sub order_type-asc order_type-desc',
                            'default' => 'all'
                        ),

                        array(
                            'type' => 'hidden',
                            'label' => $this->trans('Show "Show All" tab', array(), 'Admin.Global'),
                            'name' => 'mt_producttab_disableshowall',
                            'required' => false,
                            'is_bool' => true,
                            'values' => array(
                                array(
                                    'id' => 'showall_on',
                                    'value' => 1,
                                    'label' => $this->trans('Show', array(), 'Admin.Global')
                                ),
                                array(
                                    'id' => 'showall_off',
                                    'value' => 0,
                                    'label' => $this->trans('Hide', array(), 'Admin.Global')
                                )
                            )
                        ),
                        array(
                            'type' => 'text',
                            'name' => 'nb_products',
                            'label' => $this->trans('Limit product count per tab', array(), 'Admin.Global'),
                            'required' => true,
                            'lang' => false,
                            'suffix' => $this->trans('products per tab', array(), 'Admin.Global'),
                            'default' => '10',
                        )
                    ),
                    // Submit Button
                    'submit' => array(
                        'title' => $this->trans('Save', array(), 'Admin.Actions'),
                        'name' => 'saveIsotopeTabsOptions'
                    )
                )
            )
        );

        $helper = new HelperForm();

        $helper->module = $this;
        $helper->name_controller = $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex . '&configure=' . $this->name;

        $helper->default_form_language = $id_default_lang;
        $helper->allow_employee_form_lang = $id_default_lang;

        $helper->title = $this->displayName;
        $helper->show_toolbar = true;
        $helper->toolbar_scroll = true;
        $helper->submit_action = 'submit' . $this->name;
        $helper->toolbar_btn = array(
            'editTabs' => array(
                'desc' => $this->trans('Edit Tabs', array(), 'Modules.ProductTab.Admin'),
                'href' => $this->context->link->getAdminLink('AdminTabMenuProduct'),
                'imgclass' => 'edit'
            )
        );

        // Load current values
        $helper->fields_value['nb_products'] = Configuration::get($this->name . '_nb_products');
        $helper->fields_value['mt_producttab_disableshowall'] = Configuration::get($this->name . '_DISABLESHOWALL');
        $helper->fields_value['order_way'] = Configuration::get($this->name . '_order_way');
        $helper->fields_value['order_by'] = Configuration::get($this->name . '_order_by');

        return $helper->generateForm($fields_form);
    }

    public function hookActionShopDataDuplication($params) {
        Db::getInstance()->execute('
            INSERT IGNORE INTO ' . _DB_PREFIX_ . 'mt_producttab_shop (id_mt_producttab, id_shop)
            SELECT id_mt_producttab, ' . (int) $params['new_id_shop'] . '
            FROM ' . _DB_PREFIX_ . 'mt_producttab_shop
            WHERE id_shop = ' . (int) $params['old_id_shop']
        );
    }

    private function _getTabsList($id_shop, $id_lang) {
        $ProductTab = new Mt_ProductTabModel();
        $tabIds = $ProductTab->getTabIds($id_shop);

        $response = array();

        $patterns = array(
            '/(%)/',
            '/(\s+)/'
        );
        $replacements = array(
            '',
            '-'
        );

        if (Configuration::get($this->name . '_DISABLESHOWALL')) {
            $response[] = array(
                'title' => $this->trans('Show All', array(), 'Modules.ProductTab.Admin'),
                'filter' => '*',
                'products' => $this->_getProductsForTab(null)
            );
        }

        foreach ($tabIds as $key => $tabId) {
            $ProductTab = new Mt_ProductTabModel($tabId['id_mt_producttab'], $id_lang);

            $response[] = array(
                'title' => $ProductTab->title,
                'filter' => Tools::strtolower(preg_replace($patterns, $replacements, $ProductTab->title)),
                'products' => $this->_getProductsForTab($tabId)
            );
        }

        if ($response) {
            return $response;
        } else {
            return NULL;
        }
    }

    private function _getProductsForTab($tabId) {
      $id_default_lang = $this->context->language->id;
      $maxProductCount = Configuration::get($this->name . '_nb_products');

      $products = array();
      $content_data = $tabId ? $this->_getTabContent($tabId['id_mt_producttab']) : Product::getNewProducts($id_default_lang, 0, $maxProductCount);

      if ($content_data && sizeof($content_data) > 0) {
        foreach ($content_data[0] as $productID => $product) {
            if (array_key_exists($productID, $products)) {
                $products[$productID]['type'] .= ' ' . $product['type'];
            } else {
                $products[$productID] = $product;
            }
        }
      }

      $assembler = new ProductAssembler($this->context);
      $presenterFactory = new ProductPresenterFactory($this->context);
      $presentationSettings = $presenterFactory->getPresentationSettings();
      $presenter = new ProductListingPresenter(
              new ImageRetriever(
              $this->context->link
              ), $this->context->link, new PriceFormatter(), new ProductColorsRetriever(), $this->context->getTranslator()
      );
      $products_for_template = [];
      if (is_array($products)) {
          foreach ($products as $rawProduct) {
              $products_for_template[] = $presenter->present(
                      $presentationSettings, $assembler->assembleProduct($rawProduct), $this->context->language
              );
          }
      }

      return $products_for_template;
    }

    public static function getBestSales($id_lang, $page_number = 0, $nb_products = 3, $order_by = null, $order_way = null) {
        if ($page_number < 0)
            $page_number = 0;
        if ($nb_products < 1)
            $nb_products = 3;
        $final_order_by = $order_by;
        $order_table = '';
        if (is_null($order_by) || $order_by == 'position' || $order_by == 'price')
            $order_by = 'sales';
        if ($order_by == 'date_add' || $order_by == 'date_upd')
            $order_table = 'product_shop';
        if (is_null($order_way) || $order_by == 'sales')
            $order_way = 'DESC';

        $groups = FrontController::getCurrentCustomerGroups();
        $sql_groups = (count($groups) ? 'IN (' . implode(',', $groups) . ')' : '= 1');
        $interval = Validate::isUnsignedInt(Configuration::get('PS_NB_DAYS_NEW_PRODUCT')) ? Configuration::get('PS_NB_DAYS_NEW_PRODUCT') : 20;

        $prefix = '';
        if ($order_by == 'date_add'){
            $prefix = 'p.';
        }

        $sql = 'SELECT p.*, product_shop.*, stock.out_of_stock, IFNULL(stock.quantity, 0) as quantity,
                    pl.`description`, pl.`description_short`, pl.`link_rewrite`, pl.`meta_description`,
                    pl.`meta_keywords`, pl.`meta_title`, pl.`name`,
                    m.`name` AS manufacturer_name, p.`id_manufacturer` as id_manufacturer,
                    MAX(image_shop.`id_image`) id_image, il.`legend`,
                    ps.`quantity` AS sales, t.`rate`, pl.`meta_keywords`, pl.`meta_title`, pl.`meta_description`,
                    DATEDIFF(p.`date_add`, DATE_SUB(NOW(),
                    INTERVAL ' . $interval . ' DAY)) > 0 AS new
                FROM `' . _DB_PREFIX_ . 'product_sale` ps
                LEFT JOIN `' . _DB_PREFIX_ . 'product` p ON ps.`id_product` = p.`id_product`
                ' . Shop::addSqlAssociation('product', 'p', false) . '
                LEFT JOIN `' . _DB_PREFIX_ . 'product_lang` pl
                    ON p.`id_product` = pl.`id_product`
                    AND pl.`id_lang` = ' . (int) $id_lang . Shop::addSqlRestrictionOnLang('pl') . '
                LEFT JOIN `' . _DB_PREFIX_ . 'image` i ON (i.`id_product` = p.`id_product`)' .
                Shop::addSqlAssociation('image', 'i', false, 'image_shop.cover=1') . '
                LEFT JOIN `' . _DB_PREFIX_ . 'image_lang` il ON (i.`id_image` = il.`id_image` AND il.`id_lang` = ' . (int) $id_lang . ')
                LEFT JOIN `' . _DB_PREFIX_ . 'manufacturer` m ON (m.`id_manufacturer` = p.`id_manufacturer`)
                LEFT JOIN `' . _DB_PREFIX_ . 'tax_rule` tr ON (product_shop.`id_tax_rules_group` = tr.`id_tax_rules_group`)
                    AND tr.`id_country` = ' . (int) Context::getContext()->country->id . '
                    AND tr.`id_state` = 0
                LEFT JOIN `' . _DB_PREFIX_ . 'tax` t ON (t.`id_tax` = tr.`id_tax`)
                ' . Product::sqlStock('p') . '
                WHERE product_shop.`active` = 1
                    AND product_shop.`visibility` != \'none\'
                    AND p.`id_product` IN (
                        SELECT cp.`id_product`
                        FROM `' . _DB_PREFIX_ . 'category_group` cg
                        LEFT JOIN `' . _DB_PREFIX_ . 'category_product` cp ON (cp.`id_category` = cg.`id_category`)
                        WHERE cg.`id_group` ' . $sql_groups . '
                    )
                GROUP BY product_shop.id_product
                ORDER BY ' . (!empty($order_table) ? '`' . pSQL($order_table) . '`.' : '') . '`' . pSQL($order_by) . '` ' . pSQL($order_way) . '
                LIMIT ' . (int) ($page_number * $nb_products) . ', ' . (int) $nb_products;

        $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);

        if ($final_order_by == 'price')
            Tools::orderbyPrice($result, $order_way);
        if (!$result)
            return false;
        return Product::getProductsProperties($id_lang, $result);
    }

    public function getProductsFont($params) {
        $id_lang = $this->context->language->id;
        $context = Context::getContext();
        //assign value from params
        $page_number = isset($params['page_number']) ? $params['page_number'] : 1;
        if ($page_number < 0) {
            $page_number = 0;
        }

        $nb_products = isset($params['nb_products']) ? $params['nb_products'] : 10;
        if ($nb_products < 1) {
            $nb_products = 3;
        }
        $order_by = isset($params['order_by']) ? Tools::strtolower($params['order_by']) : 'position';
        $order_way = isset($params['order_way']) ? $params['order_way'] : 'ASC';
        $random = false;
        if ($order_way == 'random') {
            $random = true;
        }
        $get_total = isset($params['get_total']) ? $params['get_total'] : false;
        $order_by_prefix = false;
        if ($order_by == 'id_product' || $order_by == 'date_add' || $order_by == 'date_upd') {
            $order_by_prefix = 'product_shop';
        } else if ($order_by == 'reference') {
            $order_by_prefix = 'p';
        } else if ($order_by == 'name') {
            $order_by_prefix = 'pl';
        } elseif ($order_by == 'manufacturer') {
            $order_by_prefix = 'm';
            $order_by = 'name';
        } elseif ($order_by == 'position') {
            $order_by = 'date_add';
            $order_by_prefix = 'product_shop';
        }
        if ($order_by == 'price') {
            $order_by = 'orderprice';
        }
        $active = 1;
        if (!Validate::isBool($active) || !Validate::isOrderBy($order_by)) {
            die(Tools::displayError());
        }
        $where = '';
        $sql_join = '';
        $sql_group = '';

        $value_by_categories = isset($params['value_by_categories']) ? $params['value_by_categories'] : 0;
        if ($value_by_categories) {
            $id_categories = isset($params['categorybox']) ? $params['categorybox'] : '';
            if (isset($params['category_type']) && $params['category_type'] == 'default') {
                $where .= ' AND product_shop.`id_category_default` ' . (strpos($id_categories, ',') === false ?
                        '= ' . (int) $id_categories : 'IN (' . $id_categories . ')');
            } else {
                $sql_join .= ' INNER JOIN ' . _DB_PREFIX_ . 'category_product cp ON (cp.id_product= p.`id_product` )';

                $where .= ' AND cp.`id_category` ' . (strpos($id_categories, ',') === false ?
                        '= ' . (int) $id_categories : 'IN (' . $id_categories . ')');

                $sql_group = ' GROUP BY p.id_product';
            }
        }
        $value_by_supplier = isset($params['value_by_supplier']) ? $params['value_by_supplier'] : 0;
        if ($value_by_supplier && isset($params['supplier'])) {
            $id_suppliers = $params['supplier'];
            $where .= ' AND p.id_supplier ' . (strpos($id_suppliers, ',') === false ? '= ' . (int) $id_suppliers : 'IN (' . $id_suppliers . ')');
        }
        $value_by_product_id = isset($params['value_by_product_id']) ? $params['value_by_product_id'] : 0;
        if ($value_by_product_id && isset($params['product_id'])) {
            $temp = explode(',', $params['product_id']);
            foreach ($temp as $key => $value) {
                // validate module
                $temp[$key] = (int) $value;
            }

            $product_id = implode(',', $temp);
            $where .= ' AND p.id_product ' . (strpos($product_id, ',') === false ? '= ' . (int) $product_id : 'IN (' . $product_id . ')');
        }

        $value_by_manufacture = isset($params['value_by_manufacture']) ? $params['value_by_manufacture'] : 0;
        if ($value_by_manufacture && isset($params['manufacture'])) {
            $id_manufactures = $params['manufacture'];
            $where .= ' AND p.id_manufacturer ' . (strpos($id_manufactures, ',') === false ? '= ' . (int) $id_manufactures : 'IN (' . $id_manufactures . ')');
        }
        $product_type = isset($params['product_type']) ? $params['product_type'] : '';
        $value_by_product_type = isset($params['value_by_product_type']) ? $params['value_by_product_type'] : 0;
        if ($value_by_product_type && $product_type == 'new_product') {
            $where .= ' AND product_shop.`date_add` > "' . date('Y-m-d', strtotime('-' . (Configuration::get('PS_NB_DAYS_NEW_PRODUCT') ?
                                    (int) Configuration::get('PS_NB_DAYS_NEW_PRODUCT') : 20) . ' DAY')) . '"';
        }
        //home feature
        if ($value_by_product_type && $product_type == 'home_featured') {
            $ids = array();
            $category = new Category(Context::getContext()->shop->getCategory(), (int) Context::getContext()->language->id);
            $result = $category->getProducts((int) Context::getContext()->language->id, 1, $n * ($p + 1), 'position');   // Load more product $n*$p, hidden
            foreach ($result as $product) {
                $ids[$product['id_product']] = 1;
            }
            $ids = array_keys($ids);
            sort($ids);
            $ids = count($ids) > 0 ? implode(',', $ids) : 'NULL';
            $where .= ' AND p.`id_product` IN (' . $ids . ')';
        }
        //special or price drop
        if ($value_by_product_type && $product_type == 'price_drop') {
            $current_date = date('Y-m-d H:i:s');
            $id_address = $context->cart->{Configuration::get('PS_TAX_ADDRESS_TYPE')};
            $ids = Address::getCountryAndState($id_address);
            $id_country = $ids['id_country'] ? $ids['id_country'] : Configuration::get('PS_COUNTRY_DEFAULT');
            $id_country = (int) $id_country;
            $ids_product = SpecificPrice::getProductIdByDate(
                            $context->shop->id, $context->currency->id, $id_country, $context->customer->id_default_group, $current_date, $current_date, 0, false
            );
            $tab_id_product = array();
            foreach ($ids_product as $product) {
                if (is_array($product)) {
                    $tab_id_product[] = (int) $product['id_product'];
                } else {
                    $tab_id_product[] = (int) $product;
                }
            }
            $where .= ' AND p.`id_product` IN (' . ((is_array($tab_id_product) && count($tab_id_product)) ? implode(', ', $tab_id_product) : 0) . ')';
        }

        $sql = 'SELECT p.*, product_shop.*, p.`reference`, stock.out_of_stock, IFNULL(stock.quantity, 0) as quantity,
                product_attribute_shop.id_product_attribute,
                product_attribute_shop.minimal_quantity AS product_attribute_minimal_quantity,
                pl.`description`, pl.`description_short`, pl.`available_now`,
                pl.`available_later`, pl.`link_rewrite`, pl.`meta_description`, pl.`meta_keywords`, pl.`meta_title`, pl.`name`,
                image_shop.`id_image`,
                il.`legend`, m.`name` AS manufacturer_name, cl.`name` AS category_default,
                DATEDIFF(product_shop.`date_add`, DATE_SUB(NOW(),
                INTERVAL ' . (Validate::isUnsignedInt(Configuration::get('PS_NB_DAYS_NEW_PRODUCT')) ? Configuration::get('PS_NB_DAYS_NEW_PRODUCT') : 20) . '
                DAY)) > 0 AS new, product_shop.price AS orderprice';

        if ($value_by_product_type && $product_type == 'best_sellers') {
            $sql .= ' FROM `' . _DB_PREFIX_ . 'product_sale` ps';
            $sql .= ' LEFT JOIN `' . _DB_PREFIX_ . 'product` p ON ps.`id_product` = p.`id_product`';
        } else {
            $sql .= ' FROM `' . _DB_PREFIX_ . 'product` p';
        }

        $sql .= ' INNER JOIN ' . _DB_PREFIX_ . 'product_shop product_shop ON (product_shop.id_product = p.id_product AND product_shop.id_shop = ' . (int) $context->shop->id . ')
                  LEFT JOIN ' . _DB_PREFIX_ . 'product_attribute_shop product_attribute_shop ON p.`id_product` = product_attribute_shop.`id_product` AND product_attribute_shop.`default_on` = 1 AND product_attribute_shop.id_shop=' . (int) $context->shop->id . '
                    ' . ProductCore::sqlStock('p', 'product_attribute_shop', false, $context->shop) . '
                  LEFT JOIN ' . _DB_PREFIX_ . 'category_lang cl ON (product_shop.`id_category_default` = cl.`id_category` AND cl.`id_lang` = ' . (int) $id_lang . Shop::addSqlRestrictionOnLang('cl') . ')
                  LEFT JOIN ' . _DB_PREFIX_ . 'product_lang pl ON (p.`id_product` = pl.`id_product` AND pl.`id_lang` = ' . (int) $id_lang . Shop::addSqlRestrictionOnLang('pl') . ')
                  LEFT JOIN ' . _DB_PREFIX_ . 'image_shop image_shop ON (image_shop.id_product = p.id_product AND image_shop.id_shop = ' . (int) $context->shop->id . ' AND image_shop.cover=1)
                  LEFT JOIN ' . _DB_PREFIX_ . 'image_lang il ON (image_shop.`id_image` = il.`id_image` AND il.`id_lang` = ' . (int) $id_lang . ')
                  LEFT JOIN ' . _DB_PREFIX_ . 'manufacturer m ON m.`id_manufacturer` = p.`id_manufacturer`';
        $sql .= $sql_join;

        $sql .= ' WHERE product_shop.`id_shop` = ' . (int) $context->shop->id . '
                        AND product_shop.`active` = 1
                        AND product_shop.`visibility` IN ("both", "catalog")'
                . $where;

        $sql .= $sql_group;

        if ($random === true) {
            // $sql .= ' ORDER BY product_shop.date_add '.(!$get_total ? ' LIMIT '.(int)$n : '');
            $sql .= ' ORDER BY RAND() ' . (!$get_total ? ' LIMIT ' . (int) $n : '');
        } else {
            $sql .= ' ORDER BY ' . (!empty($order_by_prefix) ? $order_by_prefix . '.' : '') . '`' . bqSQL($order_by) . '` ' . pSQL($order_way)
                    . (!$get_total ? ' LIMIT ' . (((int) $p - 1) * (int) $n) . ',' . (int) $n : '');
        }
        $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);

        if ($order_by == 'orderprice') {
            Tools::orderbyPrice($result, $order_way);
        }
        if (!$result) {
            return array();
        }
        return Product::getProductsProperties($id_lang, $result);
    }

    private function _getTabContent($id_mt_producttab) {
        $id_default_lang = $this->context->language->id;
        $ProductTab = new Mt_ProductTabModel($id_mt_producttab, $id_default_lang);

        $patterns = array(
            '/(%)/',
            '/(\s+)/'
        );
        $replacements = array(
            '',
            '-'
        );

        if (Validate::isLoadedObject($ProductTab)) {
            $type = Tools::strtolower(preg_replace($patterns, $replacements, $ProductTab->title));
            $maxProductCount = Configuration::get($this->name . '_nb_products');
            $products = array();

            $banner = array();

            switch ($ProductTab->tab_type) {
                case 'featured':
                    $category = new Category($this->context->shop->getCategory(), $id_default_lang);
                    $products = $category->getProducts($id_default_lang, 1, $maxProductCount);
                    break;

                case 'new':
                    $products = Product::getNewProducts($id_default_lang, 0, $maxProductCount);
                    break;

                case 'special':
                    $products = Product::getPricesDrop($id_default_lang, 0, $maxProductCount);
                    break;

                case 'bestseller':
                    $products = $this->getBestSales((int) Context::getContext()->language->id, 0, ($maxProductCount ? $maxProductCount : 8), null, null);
                    break;

                case 'category':
                    $category = new Category($ProductTab->tab_content, $id_default_lang);
                    $products = $category->getProducts($id_default_lang, 1, $maxProductCount);
                    break;

                case 'manufacturers':
                    $manufacturers = new Manufacturer();
                    $products = $manufacturers->getProducts($ProductTab->tab_content, $id_default_lang, 1, $maxProductCount, 'position');
                    break;

                case 'custom':
                    $productIDs = explode(",", $ProductTab->tab_content);
                    $i = 0;
                    foreach ($productIDs as $id_product) {
                        if ($i < $maxProductCount) {
                            $customProduct = get_object_vars(new Product($id_product, true, $id_default_lang));
                            $customProduct['id_product'] = $customProduct['id'];

                            $coverImage = Product::getCover($customProduct['id_product']);
                            $customProduct['id_image'] = $coverImage['id_image'];

                            $products[] = Product::getProductProperties($id_default_lang, $customProduct);

                            $i++;
                        }
                    }
                    break;
            }

            if ($products) {
              $orderBy = Configuration::get($this->name . '_order_by');
              $orderWay = Configuration::get($this->name . '_order_way');
              if ($orderWay) {
                if ($orderWay == 'asc') {
                  if ($orderBy == 'id_product') usort($products, function($a, $b) { return $this->sortById($a, $b); });
                  elseif ($orderBy == 'name') usort($products, function($a, $b) { return $this->sortByName($a, $b); });
                  elseif ($orderBy == 'reference') usort($products, function($a, $b) { return $this->sortByReference($a, $b); });
                  elseif ($orderBy == 'price') usort($products, function($a, $b) { return $this->sortByPrice($a, $b); });
                  elseif ($orderBy == 'date_add') usort($products, function($a, $b) { return $this->sortByDateAdded($a, $b); });
                  elseif ($orderBy == 'date_upd') usort($products, function($a, $b) { return $this->sortByDateUpdate($a, $b); });
                  else {}
                } elseif ($orderWay == 'desc') {
                  if ($orderBy == 'id_product') usort($products, function($a, $b) { return $this->sortById($b, $a); });
                  elseif ($orderBy == 'name') usort($products, function($a, $b) { return $this->sortByName($b, $a); });
                  elseif ($orderBy == 'reference') usort($products, function($a, $b) { return $this->sortByReference($b, $a); });
                  elseif ($orderBy == 'price') usort($products, function($a, $b) { return $this->sortByPrice($b, $a); });
                  elseif ($orderBy == 'date_add') usort($products, function($a, $b) { return $this->sortByDateAdded($b, $a); });
                  elseif ($orderBy == 'date_upd') usort($products, function($a, $b) { return $this->sortByDateUpdate($b, $a); });
                  else {}
                }
              }
              return array($this->_prepareProducts($products, $type), $banner);
            } else {
                return false;
            }
        }

        return false;
    }
    private function sortById($a, $b) {
      return strcmp($a['id_product'], $b['id_product']);
    }
    private function sortByName($a, $b) {
      return strcmp($a['name'], $b['name']);
    }
    private function sortByReference($a, $b) {
      return strcmp($a['reference'], $b['reference']);
    }
    private function sortByPrice($a, $b) {
      return strcmp($a['price'], $b['price']);
    }
    private function sortByDateAdded($a, $b) {
      return strcmp($a['date_add'], $b['date_add']);
    }
    private function sortByDateUpdate($a, $b) {
      return strcmp($a['date_upd'], $b['date_upd']);
    }

    private function _prepareProducts($products, $type) {
        $tabProducts = array();

        foreach ($products as $product) {
            if (isset($product['id_product'])) {
                $id_product = $product['id_product'];
            } elseif (isset($product['id'])) {
                $id_product = $product['id'];
            } else {
                continue;
            }

            if ($product['active']) {
                $tabProducts[$id_product] = $product;
                $tabProducts[$id_product]['type'] = $type;
            }
        }

        if (isset($tabProducts)) {
            return $tabProducts;
        } else {
            return false;
        }
    }

    private function _prepHook($params) {
        $id_shop = $this->context->shop->id;
        $id_default_lang = $this->context->language->id;

        $ProductTab = new Mt_ProductTabModel();
        $tabIds = $ProductTab->getTabIds($id_shop);

        $tab_contents = array();
        $products = array();

        foreach ($tabIds as $key => $tabId) {
            $tab_contents[$tabId['id_mt_producttab']] = $this->_getTabContent($tabId['id_mt_producttab']);
            $tab_contents[$tabId['id_mt_producttab']] = $tab_contents[$tabId['id_mt_producttab']][0];
        }

        foreach ($tab_contents as $key => $productsArray) {
            if ($productsArray) {
                foreach ($productsArray as $productID => $product) {
                    if (array_key_exists($productID, $products)) {
                        $products[$productID]['type'] .= ' ' . $product['type'];
                    } else {
                        $products[$productID] = $product;
                    }
                }
            }
        }

        $assembler = new ProductAssembler($this->context);
        $presenterFactory = new ProductPresenterFactory($this->context);
        $presentationSettings = $presenterFactory->getPresentationSettings();
        $presenter = new ProductListingPresenter(
                new ImageRetriever(
                $this->context->link
                ), $this->context->link, new PriceFormatter(), new ProductColorsRetriever(), $this->context->getTranslator()
        );
        $products_for_template = [];
        if (is_array($products)) {
            foreach ($products as $rawProduct) {
                $products_for_template[] = $presenter->present(
                        $presentationSettings, $assembler->assembleProduct($rawProduct), $this->context->language
                );
            }
        }


        $id_mt_producttab = array(
            'filters' => $this->_getTabsList($id_shop, $id_default_lang),
            'products' => $products_for_template,
        );

        $this->smarty->assign('mt_producttab', $id_mt_producttab);
    }

    public function hookTabproducts($params) {
        $this->_prepHook($params);
        return $this->display(__FILE__, 'mt_producttab.tpl');
    }

    public function hookDisplayHome($params) {
        return $this->hookTabproducts($params);
    }

    public function renderWidget($hookName, array $params)
    {
        if (!$this->isCached($this->templateFile, $this->getCacheId('mt_producttab'))) {
            $this->smarty->assign($this->getWidgetVariables($hookName, $params));
        }

        return $this->fetch($this->templateFile, $this->getCacheId('mt_producttab'));
    }
    public function getWidgetVariables($hookName, array $params)
    {

    }
    public function hookDisplayBackOfficeHeader()
    {
        return '<script>
                var admin_module_access_link = \''. $this->context->link->getAdminLink('AdminModules') .'\';
            </script>';
    }
}
