<?php

class PromoBlock extends ObjectModel
{
	public $id;	
	public $id_shop;
	public $icon_info;
	public $text_info;
	public $text_info1;

	public static $definition = array(
		'table' => 'mt_promoblock',
		'primary' => 'id_info',
		'multilang' => true,
		'fields' => array(
			'id_shop' => 	array('type' => self::TYPE_INT, 'validate' => 'isunsignedInt', 'required' => true),
			'icon_info' =>	array('type' => self::TYPE_STRING, 'validate' => 'isGenericName'),
			'text_info' =>	array('type' => self::TYPE_HTML, 'lang' => true, 'validate' => 'isGenericName', 'required' => true),
			'text_info1' =>	array('type' => self::TYPE_HTML, 'lang' => true, 'validate' => 'isGenericName', 'required' => true),
		)
	);

	public function copyFromPost()
    {
		/* Classical fields */
		foreach (Tools::getAllValues() as $key => $value) {
			if (array_key_exists($key, $this) and $key != 'id_'.$this->table) {
				$this->{$key} = $value;
			}
		}

		/* Multilingual fields */
		if (sizeof($this->fieldsValidateLang)) {
			$languages = Language::getLanguages(false);
			foreach ($languages as $language) {
				foreach ($this->fieldsValidateLang as $field => $validation) {
					if (Tools::getValue($field.'_'.(int)($language['id_lang']))) {
						$this->{$field}[(int)($language['id_lang'])] = Tools::getValue($field.'_'.(int)($language['id_lang']));
					}
				}
			}
		}
    }
}