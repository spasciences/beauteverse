<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\PrestaShop\Core\Module\WidgetInterface;

include_once _PS_MODULE_DIR_.'mt_promoblock/PromoBlock.php';

class Mt_PromoBlock extends Module implements WidgetInterface
{    
    private $templateFile;

    public function __construct()
    {
        $this->name = 'mt_promoblock';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'Mahardhi';

        $this->bootstrap = true;
        parent::__construct();

        $this->displayName = $this->trans('Promo Block', array(), 'Modules.PromoBlock.Admin');
        $this->description = $this->trans('Adds promo texts in homepage.', array(), 'Modules.PromoBlock.Admin');
        $this->ps_versions_compliancy = array('min' => '1.7.4.0', 'max' => _PS_VERSION_);

        $this->templateFile = 'module:mt_promoblock/views/templates/hook/mt_promoblock.tpl';
    }

    /**
     * @see Module::install()
     */
    public function install()
    {
        return  parent::install() &&
                $this->createTables() &&
                $this->registerHook('displayHome') &&
                $this->installFixtures();
    }

     public function installFixtures()
    {
        $return = true;
        $tab_texts = array(
             array(
                'icon_info' => 'plane1',
                'text_info' => 'Free Worldwide Shipping',
                'text_info1' => 'On order over $150'
            ),
            array(
                'icon_info' => 'wallet',
                'text_info' => 'Money Back Guarantee',
                'text_info1' => 'Cash on delivery'
            ),
            array(
                'icon_info' => 'gift',
                'text_info' => 'Special Gift Card',
                'text_info1' => 'Offer special bonuses with gift'
            ),
            array(
                'icon_info' => 'support',
                'text_info' => 'Best Online Support',
                'text_info1' => 'Call us 24/7 at 123-456-789'
            )
        );

        foreach ($tab_texts as $tab) {
            $info = new PromoBlock();
            $info->icon_info = $tab['icon_info'];
            foreach (Language::getLanguages(false) as $lang) {
                $info->text_info[$lang['id_lang']] = $tab['text_info'];
                $info->text_info1[$lang['id_lang']] = $tab['text_info1'];
            }
            $info->id_shop = $this->context->shop->id;
            $return &= $info->save();
        }
        return $return;
    }

    /**
     * Creates tables
     */
    protected function createTables()
    {
        /* Slides */
        $res = (bool)Db::getInstance()->execute('
            CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'mt_promoblock` (
                `id_info` int(10) unsigned NOT NULL AUTO_INCREMENT,
                `id_shop` int(10) unsigned NOT NULL,
                `icon_info` varchar(30) NOT NULL,
                PRIMARY KEY (`id_info`)
            ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=UTF8;
        ');

        /* Slides lang configuration */
        $res &= Db::getInstance()->execute('
            CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'mt_promoblock_lang` (
              `id_info` int(10) unsigned NOT NULL,
              `id_lang` int(10) unsigned NOT NULL,
              `text_info` text NOT NULL,
              `text_info1` text NOT NULL,
              PRIMARY KEY (`id_info`,`id_lang`)
            ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=UTF8;
        ');

        return $res;
    }

    /**
     * @see Module::uninstall()
     */
    public function uninstall()
    {
        return parent::uninstall() && $this->deleteTables();
    }   

    /**
     * deletes tables
     */
    protected function deleteTables()
    {
        return Db::getInstance()->execute('
            DROP TABLE IF EXISTS `'._DB_PREFIX_.'mt_promoblock`, `'._DB_PREFIX_.'mt_promoblock_lang`;
        ');
    }

    public function getContent()
    {
        $html = '';
        $id_info = (int)Tools::getValue('id_info');
        $info = new PromoBlock();

        if (Tools::isSubmit('saveModule')) {
            if ($id_info = Tools::getValue('id_info')) {
                $info = new PromoBlock((int)$id_info);
            } else {
                $info = new PromoBlock();
            }

            $info->copyFromPost();
            $info->id_shop = $this->context->shop->id;

            if ($info->validateFields(false) && $info->validateFieldsLang(false)) {
                $info->save();
                $this->_clearCache('*');
            } else {
                $html .= '<div class="conf error">'.$this->trans('An error occurred while attempting to save.', array(), 'Admin.Notifications.Error').'</div>';
            }
        }

        if (Tools::isSubmit('updateModule') || Tools::isSubmit('addModule')) {
            $helper = $this->initForm();
            foreach (Language::getLanguages(false) as $lang) {
                if ($id_info) {
                    $info = new PromoBlock((int)$id_info);
                    $helper->fields_value['text_info'][(int)$lang['id_lang']] = $info->text_info[(int)$lang['id_lang']];
                    $helper->fields_value['text_info1'][(int)$lang['id_lang']] = $info->text_info1[(int)$lang['id_lang']];
                } else {
                    $helper->fields_value['text_info'][(int)$lang['id_lang']] = Tools::getValue('text_info_'.(int)$lang['id_lang'], '');
                    $helper->fields_value['text_info1'][(int)$lang['id_lang']] = Tools::getValue('text_info1_'.(int)$lang['id_lang'], '');
                }
            }
            $helper->fields_value['icon_info'] = $info->icon_info;
            if ($id_info = Tools::getValue('id_info')) {
                $this->fields_form[0]['form']['input'][] = array('type' => 'hidden', 'name' => 'id_info');
                $helper->fields_value['id_info'] = (int)$id_info;
            }

            return $html.$helper->generateForm($this->fields_form);
        } elseif (Tools::isSubmit('deleteModule')) {
            $info = new PromoBlock((int)$id_info);
            $info->delete();
            $this->_clearCache('*');
            Tools::redirectAdmin(AdminController::$currentIndex.'&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules'));
        } else {
            $content = $this->getListContent((int)Configuration::get('PS_LANG_DEFAULT'));
            $helper = $this->initList();
            $helper->listTotal = count($content);
            return $html.$helper->generateList($content, $this->fields_list);
        }
    }

    public function getListContent($id_lang)
    {
        return  Db::getInstance()->executeS('
            SELECT r.`id_info`, r.`id_shop`, r.`icon_info`, rl.`text_info`, rl.`text_info1`
            FROM `'._DB_PREFIX_.'mt_promoblock` r
            LEFT JOIN `'._DB_PREFIX_.'mt_promoblock_lang` rl ON (r.`id_info` = rl.`id_info`)
            WHERE `id_lang` = '.(int)$id_lang.' '.Shop::addSqlRestrictionOnLang());
    }

    public function initForm()
    {
        $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');

        $this->fields_form[0]['form'] = array(
            'legend' => array(
                'title' =>$this->trans('Custom Texts', array(), 'Admin.Global'),
            ),
            'input' => array(
                array(
                    'type' => 'text',
                    'label' => $this->trans('Icon Name', array(), 'Modules.PromoBlock.Admin'),
                    'name' => 'icon_info',
                ),
                array(
                    'type' => 'text',
                    'label' => $this->trans('Texts', array(), 'Modules.PromoBlock.Admin'),
                    'lang' => true,
                    'name' => 'text_info'
                ),
                array(
                    'type' => 'text',
                    'label' => $this->trans('Description', array(), 'Modules.PromoBlock.Admin'),
                    'lang' => true,
                    'name' => 'text_info1'
                )
            ),
            'submit' => array(
                'title' => $this->trans('Save', array(), 'Admin.Actions'),
            )
        );

        $helper = new HelperForm();
        $helper->module = $this;
        $helper->name_controller = 'mt_promoblock';
        $helper->identifier = $this->identifier;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        foreach (Language::getLanguages(false) as $lang) {
            $helper->languages[] = array(
                'id_lang' => $lang['id_lang'],
                'iso_code' => $lang['iso_code'],
                'name' => $lang['name'],
                'is_default' => ($default_lang == $lang['id_lang'] ? 1 : 0)
            );
        }

        $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;
        $helper->default_form_language = $default_lang;
        $helper->allow_employee_form_lang = $default_lang;
        $helper->toolbar_scroll = true;
        $helper->title = $this->displayName;
        $helper->submit_action = 'saveModule';
        $helper->toolbar_btn =  array(
            'save' =>
            array(
                'desc' => $this->trans('Save', array(), 'Admin.Actions'),
                'href' => AdminController::$currentIndex.'&configure='.$this->name.'&saveModule&token='.Tools::getAdminTokenLite('AdminModules'),
            ),
            'back' =>
            array(
                'href' => AdminController::$currentIndex.'&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules'),
                'desc' => $this->trans('Back to list', array(), 'Admin.Actions'),
            )
        );
        return $helper;
    }

    public function initList()
    {
        $this->fields_list = array(
            'id_info' => array(
                'title' => $this->trans('ID', array(), 'Modules.PromoBlock.Admin'),
                'type' => 'text',
                'search' => false,
                'orderby' => false
            ),
            'text_info' => array(
                'title' => $this->trans('Texts', array(), 'Modules.PromoBlock.Admin'),
                'type' => 'text',
                'search' => false,
                'orderby' => false
            ),
            'text_info1' => array(
                'title' => $this->trans('Description', array(), 'Modules.PromoBlock.Admin'),
                'type' => 'text',
                'search' => false,
                'orderby' => false
            ),
        );

        if (Shop::isFeatureActive()) {
            $this->fields_list['id_shop'] = array(
                'title' => $this->trans('Shop ID', array(), 'Modules.PromoBlock.Admin'),
                'type' => 'int'
            );
        }

        $helper = new HelperList();
        $helper->shopLinkType = '';
        $helper->simple_header = false;
        $helper->identifier = 'id_info';
        $helper->actions = array('edit', 'delete');
        $helper->show_toolbar = true;
        $helper->imageType = 'jpg';
        $helper->toolbar_btn['new'] = array(
            'href' => AdminController::$currentIndex.'&configure='.$this->name.'&addModule&token='.Tools::getAdminTokenLite('AdminModules'),
            'desc' => $this->trans('Add new', array(), 'Modules.PromoBlock.Admin')
        );

        $helper->title = $this->displayName;
        $helper->table = 'Module';
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;
        return $helper;
    }

    public function clearCache()
    {
        $this->_clearCache($this->templateFile);
    }

    public function renderWidget($hookName = null, array $configuration = [])
    {
        if (!$this->isCached($this->templateFile, $this->getCacheId('mt_promoblock'))) {
            $this->smarty->assign($this->getWidgetVariables($hookName, $configuration));
        }

        return $this->fetch($this->templateFile, $this->getCacheId('mt_promoblock'));
       
    }

    public function getWidgetVariables($hookName = null, array $configuration = [])
    {
        $infos = $this->getListContent($this->context->language->id);

        return array(
            'infos' => $infos,
        );
    }
}