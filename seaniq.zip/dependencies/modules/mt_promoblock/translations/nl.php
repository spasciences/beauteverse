<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mt_promoblock}prestashop>mt_promoblock_1e980be82d024fb59b697e6d12d7aefa'] = 'Onze diensten';
