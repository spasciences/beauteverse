<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mt_compare}prestashop>mt_compare_59c533b287338f11f4cdca5a4b71df47'] = 'Het product is toegevoegd aan lijst vergelijken';
$_MODULE['<{mt_compare}prestashop>mt_compare_fdf96b7e3bfda00d1188bab3e57b0216'] = 'Het product is succesvol verwijderd uit de lijst vergelijken';
$_MODULE['<{mt_compare}prestashop>mt_compare_65ac95235742472c455c9911b8a96cbd'] = 'Vergelijkingslijst bijgewerkt!';
$_MODULE['<{mt_compare}prestashop>mt_compare_cd7e3c468247895471fb538d5ace2de4'] = 'Product succesvol toegevoegd aan de productvergelijking!';
$_MODULE['<{mt_compare}prestashop>mt_compare_c5f5d9058a9f4ba8cb522b939e3ed496'] = 'Ga naar vergelijken';
$_MODULE['<{mt_compare}prestashop>mt_compare_dc3fd488f03d423a04da27ce66274c1b'] = 'Waarschuwing!';
$_MODULE['<{mt_compare}prestashop>mt_compare_84102147332eb050df7ff64a25ebbb8c'] = 'Product succesvol verwijderd uit de productvergelijking!';
$_MODULE['<{mt_compare}prestashop>products-comparison_1c244f5a3415bb905e8c8751b648558d'] = 'Mijn vergelijking';
$_MODULE['<{mt_compare}prestashop>products-comparison_4dbce7d8fae730e09fce9e83433c77ff'] = 'productvergelijking';
$_MODULE['<{mt_compare}prestashop>products-comparison_d6295c05503596b3ed3528aee83e3ef7'] = 'Kenmerken:';
$_MODULE['<{mt_compare}prestashop>products-comparison_03c2e7e41ffc181a4e84080b4710e81e'] = 'Nieuw';
$_MODULE['<{mt_compare}prestashop>products-comparison_f2cd171bd42220283b7a595c3ff2aaaf'] = 'Uitverkoop';
$_MODULE['<{mt_compare}prestashop>products-comparison_2d0f6b8300be19cf35e89e66f0677f95'] = 'Voeg toe aan winkelkar';
$_MODULE['<{mt_compare}prestashop>products-comparison_e990b6285ed2a575c561235378a5e691'] = 'Voeg toe aan winkelkar';
$_MODULE['<{mt_compare}prestashop>products-comparison_f5e15309ff0396474b8421ef48871d0b'] = 'Geen functies om te vergelijken';
$_MODULE['<{mt_compare}prestashop>products-comparison_234a9674e80b9c04a685075ad3ea6950'] = 'Er zijn geen producten geselecteerd om te vergelijken.';
$_MODULE['<{mt_compare}prestashop>products-comparison_c20905e8fdd34a1bf81984e597436134'] = 'Doorgaan met winkelen';
$_MODULE['<{mt_compare}prestashop>mt_compare_button_201f644e542b0230551936ae7af3169e'] = 'Verwijderen uit Vergelijken';
$_MODULE['<{mt_compare}prestashop>mt_compare_button_7f5508c884f40e3378895c83d99cbbd3'] = 'Voeg toe om te vergelijken';
$_MODULE['<{mt_compare}prestashop>mt_compare_nav2_7eece51cf3938103677db7a5051ef8f5'] = 'Vergelijken';
