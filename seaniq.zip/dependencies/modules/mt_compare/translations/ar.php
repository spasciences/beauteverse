<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mt_compare}prestashop>mt_compare_59c533b287338f11f4cdca5a4b71df47'] = 'تمت إضافة المنتج إلى قائمة المقارنة';
$_MODULE['<{mt_compare}prestashop>mt_compare_fdf96b7e3bfda00d1188bab3e57b0216'] = 'تمت إزالة المنتج بنجاح من قائمة المقارنة';
$_MODULE['<{mt_compare}prestashop>mt_compare_65ac95235742472c455c9911b8a96cbd'] = 'تم تحديث قائمة المقارنة!';
$_MODULE['<{mt_compare}prestashop>mt_compare_cd7e3c468247895471fb538d5ace2de4'] = 'تمت إضافة المنتج بنجاح إلى مقارنة المنتج!';
$_MODULE['<{mt_compare}prestashop>mt_compare_c5f5d9058a9f4ba8cb522b939e3ed496'] = 'اذهب إلى قارن';
$_MODULE['<{mt_compare}prestashop>mt_compare_dc3fd488f03d423a04da27ce66274c1b'] = 'تحذير!';
$_MODULE['<{mt_compare}prestashop>mt_compare_84102147332eb050df7ff64a25ebbb8c'] = 'تمت إزالة المنتج بنجاح من مقارنة المنتج!';
$_MODULE['<{mt_compare}prestashop>products-comparison_1c244f5a3415bb905e8c8751b648558d'] = 'مقارنتي';
$_MODULE['<{mt_compare}prestashop>products-comparison_4dbce7d8fae730e09fce9e83433c77ff'] = 'مقارنة السلعة';
$_MODULE['<{mt_compare}prestashop>products-comparison_d6295c05503596b3ed3528aee83e3ef7'] = 'ميزات:';
$_MODULE['<{mt_compare}prestashop>products-comparison_03c2e7e41ffc181a4e84080b4710e81e'] = 'جديد';
$_MODULE['<{mt_compare}prestashop>products-comparison_f2cd171bd42220283b7a595c3ff2aaaf'] = 'تخفيض السعر';
$_MODULE['<{mt_compare}prestashop>products-comparison_2d0f6b8300be19cf35e89e66f0677f95'] = 'أضف إلى السلة';
$_MODULE['<{mt_compare}prestashop>products-comparison_e990b6285ed2a575c561235378a5e691'] = 'إنتهى من المخزن';
$_MODULE['<{mt_compare}prestashop>products-comparison_f5e15309ff0396474b8421ef48871d0b'] = 'أي ميزات للمقارنة';
$_MODULE['<{mt_compare}prestashop>products-comparison_234a9674e80b9c04a685075ad3ea6950'] = 'لا توجد منتجات مختارة للمقارنة.';
$_MODULE['<{mt_compare}prestashop>products-comparison_c20905e8fdd34a1bf81984e597436134'] = 'مواصلة التسوق';
$_MODULE['<{mt_compare}prestashop>mt_compare_button_201f644e542b0230551936ae7af3169e'] = 'إزالة من المقارنة';
$_MODULE['<{mt_compare}prestashop>mt_compare_button_7f5508c884f40e3378895c83d99cbbd3'] = 'أضف للمقارنة';
$_MODULE['<{mt_compare}prestashop>mt_compare_nav2_7eece51cf3938103677db7a5051ef8f5'] = 'قارن';
