<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mt_compare}prestashop>mt_compare_59c533b287338f11f4cdca5a4b71df47'] = 'O produto foi adicionado à lista de comparação';
$_MODULE['<{mt_compare}prestashop>mt_compare_fdf96b7e3bfda00d1188bab3e57b0216'] = 'O produto foi removido com sucesso da comparação da lista';
$_MODULE['<{mt_compare}prestashop>mt_compare_65ac95235742472c455c9911b8a96cbd'] = 'Lista de comparação atualizada!';
$_MODULE['<{mt_compare}prestashop>mt_compare_cd7e3c468247895471fb538d5ace2de4'] = 'Produto adicionado com sucesso à comparação de produtos!';
$_MODULE['<{mt_compare}prestashop>mt_compare_c5f5d9058a9f4ba8cb522b939e3ed496'] = 'Ir para Comparar';
$_MODULE['<{mt_compare}prestashop>mt_compare_dc3fd488f03d423a04da27ce66274c1b'] = 'Atenção!';
$_MODULE['<{mt_compare}prestashop>mt_compare_84102147332eb050df7ff64a25ebbb8c'] = 'Produto removido com sucesso da comparação de produtos!';
$_MODULE['<{mt_compare}prestashop>products-comparison_1c244f5a3415bb905e8c8751b648558d'] = 'Minha comparação';
$_MODULE['<{mt_compare}prestashop>products-comparison_4dbce7d8fae730e09fce9e83433c77ff'] = 'Comparação de Produto';
$_MODULE['<{mt_compare}prestashop>products-comparison_d6295c05503596b3ed3528aee83e3ef7'] = 'Recursos:';
$_MODULE['<{mt_compare}prestashop>products-comparison_03c2e7e41ffc181a4e84080b4710e81e'] = 'New';
$_MODULE['<{mt_compare}prestashop>products-comparison_f2cd171bd42220283b7a595c3ff2aaaf'] = 'Sale';
$_MODULE['<{mt_compare}prestashop>products-comparison_2d0f6b8300be19cf35e89e66f0677f95'] = 'Adicionar ao carrinho';
$_MODULE['<{mt_compare}prestashop>products-comparison_e990b6285ed2a575c561235378a5e691'] = 'Fora de estoque';
$_MODULE['<{mt_compare}prestashop>products-comparison_f5e15309ff0396474b8421ef48871d0b'] = 'Nenhuma característica para comparar';
$_MODULE['<{mt_compare}prestashop>products-comparison_234a9674e80b9c04a685075ad3ea6950'] = 'Não há produtos selecionados para comparação.';
$_MODULE['<{mt_compare}prestashop>products-comparison_c20905e8fdd34a1bf81984e597436134'] = 'Continue comprando';
$_MODULE['<{mt_compare}prestashop>mt_compare_button_201f644e542b0230551936ae7af3169e'] = 'Remover da comparação';
$_MODULE['<{mt_compare}prestashop>mt_compare_button_7f5508c884f40e3378895c83d99cbbd3'] = 'Adicionar para comparar';
$_MODULE['<{mt_compare}prestashop>mt_compare_nav2_7eece51cf3938103677db7a5051ef8f5'] = 'Comparar';
