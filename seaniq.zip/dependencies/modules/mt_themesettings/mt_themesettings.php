<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\PrestaShop\Core\Module\WidgetInterface;

class Mt_ThemeSettings extends Module implements WidgetInterface
{
    private $templateFile;

    public function __construct()
    {
        $this->name = 'mt_themesettings';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'Mahardhi';        
        $this->need_instance = 0;
        
        $this->bootstrap = true;
        parent::__construct();

        $this->displayName = $this->trans('Theme Settings', array(), 'Modules.ThemeSettings.Admin');
        $this->description = $this->trans('Changes Theme Settings.', array(), 'Modules.ThemeSettings.Admin');
        $this->ps_versions_compliancy = array('min' => '1.7.4.0', 'max' => _PS_VERSION_);

        $this->templateFile = 'module:mt_themesettings/views/templates/hook/mt_themesettings.tpl';
    }

    /**
     * @see Module::install()
     */
    public function install()
    {
        return (parent::install()        
        && $this->registerHook('displayHeader')
        && $this->registerHook('displayAfterBodyOpeningTag')
        && Configuration::updateValue('MT_BODY_BACKGROUND', 'ffffff')
        );
    }

    /**
     * @see Module::uninstall()
     */
    public function uninstall()
    {
        return ( parent::uninstall() 
        && Configuration::deleteByName('MT_BODY_BACKGROUND')    
        );
    }

    public function hookdisplayHeader($params)
    {
        $this->context->controller->registerStylesheet('modules-font-awesome.min', 'modules/'.$this->name.'/css/font-awesome.min.css', ['media' => 'all', 'priority' => 150]);
        $this->context->controller->registerStylesheet('modules-font-mahardhi', 'modules/'.$this->name.'/css/mahardhi-font.css', ['media' => 'all', 'priority' => 150]);
        $this->context->controller->registerStylesheet('modules-owl.carousel.min', 'modules/'.$this->name.'/css/owl.carousel.min.css', ['media' => 'all', 'priority' => 150]);
        $this->context->controller->registerStylesheet('modules-slick-css', 'modules/'.$this->name.'/css/slick.css', ['media' => 'all', 'priority' => 150]);
        $this->context->controller->registerStylesheet('modules-animate.min', 'modules/'.$this->name.'/css/animate.min.css', ['media' => 'all', 'priority' => 150]);
        $this->context->controller->registerStylesheet('modules-magnific-css', 'modules/'.$this->name.'/css/magnific-popup.css', ['media' => 'all', 'priority' => 150]);
        $this->context->controller->registerJavascript('modules-cookie', 'modules/'.$this->name.'/js/jquery.cookie.js', ['position' => 'bottom', 'priority' => 1]);
        $this->context->controller->registerJavascript('modules-owl.carousel', 'modules/'.$this->name.'/js/owl.carousel.min.js', ['position' => 'bottom', 'priority' => 2]);
        $this->context->controller->registerJavascript('modules-slick', 'modules/'.$this->name.'/js/slick.js', ['position' => 'bottom', 'priority' => 3]);
        $this->context->controller->registerJavascript('modules-magnific', 'modules/'.$this->name.'/js/jquery.magnific-popup.min.js', ['position' => 'bottom', 'priority' => 4]);
        $this->context->controller->registerJavascript('modules-zoom', 'modules/'.$this->name.'/js/jquery.zoom.min.js', ['position' => 'bottom', 'priority' => 5]);
    }

    public function getContent()
    {
        $html = '';
        if (Tools::isSubmit('submitThemeSettings'))
        {  
            
            Configuration::updateValue('MT_BODY_BACKGROUND', Tools::getValue('MT_BODY_BACKGROUND'));  
            $html .= $this->getTranslator()->trans('The settings have been updated.', array(), 'Modules.ThemeSettings.Admin');
        }

        $html .= $this->renderSettingsForm();

        return $html;
    }

    public function renderSettingsForm()
    {
        $fields_form = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->getTranslator()->trans('Theme Settings', array(), 'Modules.ThemeSettings.Admin'),
                    'icon' => 'icon-cogs'
                ),
                'input' => array(  
                    array(
                        'type' => 'text',
                        'label' => $this->getTranslator()->trans('Body Background', array(), 'Modules.ThemeSettings.Admin'),
                        'name' => 'MT_BODY_BACKGROUND',
                        'maxlength' => "6",
                        'class' => 'fixed-width-sm'
                    ),
                ),
                'submit' => array(
                    'title' => $this->getTranslator()->trans('Save', array(), 'Admin.Actions'),
                )
            ),
        );

        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->submit_action = 'submitThemeSettings';
        $helper->tpl_vars = array(            
            'fields_value' => $this->getConfigFieldsValues(),
            
        );

        return $helper->generateForm(array($fields_form));
        
    }

    public function getConfigFieldsValues()
    {
        return array(            
            'MT_BODY_BACKGROUND' => Tools::getValue('MT_BODY_BACKGROUND', Configuration::get('MT_BODY_BACKGROUND'))
        );
    }

    public function renderWidget($hookName = null, array $configuration = [])
    {
        if ($hookName == 'displayAfterBodyOpeningTag' ) {
            $this->smarty->assign($this->getWidgetVariables($hookName, $configuration));
            return $this->fetch($this->templateFile);
        }
    }

    public function getWidgetVariables($hookName = null, array $configuration = [])
    {     
        return array(
           'body_backgroud' => Configuration::get('MT_BODY_BACKGROUND')            
        );
    }
}