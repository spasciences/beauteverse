<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\PrestaShop\Core\Module\WidgetInterface;

require_once _PS_MODULE_DIR_.'mt_footerhtml/FooterHtml.php';

class Mt_Footerhtml extends Module implements WidgetInterface
{
    protected $html = '';
    private $templateFile;

    public function __construct()
    {
        $this->name = 'mt_footerhtml';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'Mahardhi';
        $this->need_instance = 0;
        $this->secure_key = Tools::encrypt($this->name);
        $this->bootstrap = true;
        parent::__construct();

        $this->displayName = $this->trans('Custom Footer Html Blocks', array(), 'Modules.Footerhtml.Admin');
        $this->description = $this->trans('Adds custom information block in your store.', array(), 'Modules.Footerhtml.Admin');
        $this->ps_versions_compliancy = array('min' => '1.7.4.0', 'max' => _PS_VERSION_);

        $this->templateFile = 'module:mt_footerhtml/views/templates/hook/FooterHtml.tpl';
    }

    public function install()
    {
        return  parent::install() &&
                $this->installDB() &&
                $this->registerHook('displayFooter') &&
                $this->installFixtures();
    }

    public function installDB()
    {
        $return = true;
        $return &= Db::getInstance()->execute('
                CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'mt_footerhtml` (
                `id_footerhtml` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `id_shop` int(10) unsigned DEFAULT NULL,
                PRIMARY KEY (`id_footerhtml`)
            ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8 ;'
        );

        $return &= Db::getInstance()->execute('
                CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'mt_footerhtml_lang` (
                `id_footerhtml` INT UNSIGNED NOT NULL,
                `id_lang` int(10) unsigned NOT NULL ,
                `text` text NOT NULL,
                PRIMARY KEY (`id_footerhtml`, `id_lang`)
            ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8 ;'
        );

        return $return;
    }

    public function uninstall()
    {
        return parent::uninstall() && $this->uninstallDB();
    }

    public function uninstallDB($drop_table = true)
    {
        $ret = true;
        if ($drop_table) {
            $ret &=  Db::getInstance()->execute('DROP TABLE IF EXISTS `'._DB_PREFIX_.'mt_footerhtml`') && Db::getInstance()->execute('DROP TABLE IF EXISTS `'._DB_PREFIX_.'mt_footerhtml_lang`');
        }

        return $ret;
    }

    public function getContent()
    {
        if (Tools::isSubmit('submitModule')) {
            if (!Tools::getValue('text_'.(int)Configuration::get('PS_LANG_DEFAULT'), false)) {
                return $this->html . $this->displayError($this->trans('Please fill out all fields.', array(), 'Admin.Notifications.Error')) . $this->renderForm();
            } else {
                $this->processSaveModule();
                return $this->html . $this->renderForm();
            }
        } else {
            $this->html .= $this->renderForm();
            return $this->html;
        }
    }

    public function processSaveModule()
    {
        $footerhtml = new FooterHtml(Tools::getValue('id_footerhtml', 1));
        $languages = Language::getLanguages(false);
        $text = array();
        foreach ($languages as $lang) {
            $text[$lang['id_lang']] = Tools::getValue('text_'.$lang['id_lang']);
        }
        $footerhtml->text = $text;

        if (Shop::isFeatureActive() && !$footerhtml->id_shop) {
            $saved = true;
            foreach ($shop_ids as $id_shop) {
                $footerhtml->id_shop = $id_shop;
                $saved &= $footerhtml->add();
            }
        } else {
            $saved = $footerhtml->save();
        }

        if ($saved) {
            Tools::clearCache();
        } else {
            $this->html .=
                '<div class="alert alert-danger conf error">'
                    .$this->trans('An error occurred on saving.', array(), 'Admin.Notifications.Error')
                .'</div>';
        }

        return $saved;
    }

    protected function renderForm()
    {
        $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');

        $fields_form = array(
            'tinymce' => true,
            'legend' => array(
                'title' => $this->trans('Settings', array(), 'Modules.Footerhtml.Admin'),
            ),
            'input' => array(
                'id_footerhtml' => array(
                    'type' => 'hidden',
                    'name' => 'id_footerhtml'
                ),
                'content' => array(
                    'type' => 'textarea',
                    'label' => $this->trans('Custom texts', array(), 'Modules.Footerhtml.Admin'),
                    'lang' => true,
                    'name' => 'text',
                    'cols' => 40,
                    'rows' => 10,
                    'class' => 'rte',
                    'autoload_rte' => true,
                ),
            ),
            'submit' => array(
                'title' => $this->trans('Save', array(), 'Admin.Actions'),
            )
        );

        if (Shop::isFeatureActive() && Tools::getValue('id_footerhtml') == false) {
            $fields_form['input'][] = array(
                'type' => 'shop',
                'label' => $this->trans('Shop association', array(), 'Modules.Footerhtml.Admin'),
                'name' => 'checkBoxShopAsso_theme'
            );
        }


        $helper = new HelperForm();
        $helper->module = $this;
        $helper->name_controller = 'mt_footerhtml';
        $helper->identifier = $this->identifier;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        foreach (Language::getLanguages(false) as $lang) {
            $helper->languages[] = array(
                'id_lang' => $lang['id_lang'],
                'iso_code' => $lang['iso_code'],
                'name' => $lang['name'],
                'is_default' => ($default_lang == $lang['id_lang'] ? 1 : 0)
            );
        }

        $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;
        $helper->default_form_language = $default_lang;
        $helper->allow_employee_form_lang = $default_lang;
        $helper->toolbar_scroll = true;
        $helper->title = $this->displayName;
        $helper->submit_action = 'submitModule';

        $helper->fields_value = $this->getFormValues();

        return $helper->generateForm(array(array('form' => $fields_form)));
    }

    public function getFormValues()
    {
        $fields_value = array();
        $id_footerhtml = 1;

        foreach (Language::getLanguages(false) as $lang) {
            $footerhtml = new FooterHtml((int)$id_footerhtml);
            $fields_value['text'][(int)$lang['id_lang']] = $footerhtml->text[(int)$lang['id_lang']];
        }

        $fields_value['id_footerhtml'] = $id_footerhtml;

        return $fields_value;
    }

    public function renderWidget($hookName = null, array $configuration = [])
    {
        $this->smarty->assign($this->getWidgetVariables($hookName, $configuration));

        return $this->fetch($this->templateFile, $this->getCacheId('mt_footerhtml'));
    }
    public function getWidgetVariables($hookName = null, array $configuration = [])
    {
        $sql = 'SELECT r.`id_footerhtml`, r.`id_shop`, rl.`text`
            FROM `'._DB_PREFIX_.'mt_footerhtml` r
            LEFT JOIN `'._DB_PREFIX_.'mt_footerhtml_lang` rl ON (r.`id_footerhtml` = rl.`id_footerhtml`)
            WHERE `id_lang` = '.(int)$this->context->language->id.' AND  `id_shop` = '.(int)$this->context->shop->id;

        return [
            'footerhtml' => Db::getInstance()->getRow($sql),
        ];
    }

    public function installFixtures()
    {
        $return = true;
        $tab_texts = array(
            array(
                
                'text' => '<div class="footer-about-block">
                          <div class="about-logo">
                            <a href="#"><img src="'._MODULE_DIR_.$this->name.'/img/logo.png'.'" alt="Logo" /></a>
                          </div>
                          <div class="footer-desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt lorem consectetur tempor incididunt enim ad minim simply random text. It has pieceveniam.</div>
                          <div class="block-social">
                            <h6 class="widget-title">Follow Us</h6>
                            <ul class="social-links list-unstyled">
                                <li class="facebook social_block">
                                    <a href="#">
                                    <i class="fa fa-facebook" aria-hidden="true"></i>
                                    </a>
                                </li>
                                <li class="twitter social_block">
                                    <a href="#">
                                    <i class="fa fa-twitter" aria-hidden="true"></i>
                                    </a>
                                </li>
                                <li class="googleplus social_block">
                                    <a href="#">
                                    <i class="fa fa-google-plus" aria-hidden="true"></i>
                                    </a>
                                </li>
                                <li class="linkedin social_block">
                                    <a href="#"> <i class="fa fa-linkedin-square" aria-hidden="true"></i>
                                    </a>
                                </li>
                                <li class="pinterest social_block">
                                    <a href="#">
                                    <i class="fa fa-pinterest-p" aria-hidden="true"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        </div>'
            ),
        );

        $shops_ids = Shop::getShops(true, null, true);

        foreach ($tab_texts as $tab) {
            $footerhtml = new FooterHtml();
            foreach (Language::getLanguages(false) as $lang) {
                $footerhtml->text[$lang['id_lang']] = $tab['text'];
            }
            foreach ($shops_ids as $id_shop) {
                $footerhtml->id_shop = $id_shop;
                $return &= $footerhtml->add();
            }
        }

        return $return;
    }
}