<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\PrestaShop\Core\Module\WidgetInterface;

require_once _PS_MODULE_DIR_.'mt_footerpayment/FooterPayment.php';

class Mt_FooterPayment extends Module implements WidgetInterface
{
    protected $html = '';
    private $templateFile;

    public function __construct()
    {
        $this->name = 'mt_footerpayment';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'Mahardhi';
        $this->need_instance = 0;
        $this->secure_key = Tools::encrypt($this->name);
        $this->bootstrap = true;
        parent::__construct();

        $this->displayName = $this->trans('Footer Payment Images', array(), 'Modules.FooterPayment.Admin');
        $this->description = $this->trans('Displays a banner on footer.', array(), 'Modules.FooterPayment.Admin');

        $this->ps_versions_compliancy = array('min' => '1.7.4.0', 'max' => _PS_VERSION_);

        $this->templateFile = 'module:mt_footerpayment/views/templates/hook/FooterPayment.tpl';
    }

    public function install()
    {
        return  parent::install() &&
                $this->installDB() &&
                $this->registerHook('displayFooterPayment') &&
                $this->installFixtures();
    }

    public function installDB()
    {
        $return = true;
        $return &= Db::getInstance()->execute('
                CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'mt_footerpayment` (
                `id_footerpayment` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `id_shop` int(10) unsigned DEFAULT NULL,
                PRIMARY KEY (`id_footerpayment`)
            ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8 ;'
        );

        $return &= Db::getInstance()->execute('
                CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'mt_footerpayment_lang` (
                `id_footerpayment` INT UNSIGNED NOT NULL,
                `id_lang` int(10) unsigned NOT NULL ,
                `text` text NOT NULL,
                PRIMARY KEY (`id_footerpayment`, `id_lang`)
            ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8 ;'
        );

        return $return;
    }

    public function uninstall()
    {
        return parent::uninstall() && $this->uninstallDB();
    }

    public function uninstallDB($drop_table = true)
    {
        $ret = true;
        if ($drop_table) {
            $ret &=  Db::getInstance()->execute('DROP TABLE IF EXISTS `'._DB_PREFIX_.'mt_footerpayment`') && Db::getInstance()->execute('DROP TABLE IF EXISTS `'._DB_PREFIX_.'mt_footerpayment_lang`');
        }

        return $ret;
    }

    public function getContent()
    {
        if (Tools::isSubmit('submitModule')) {
            if (!Tools::getValue('text_'.(int)Configuration::get('PS_LANG_DEFAULT'), false)) {
                return $this->html . $this->displayError($this->trans('Please fill out all fields.', array(), 'Admin.Notifications.Error')) . $this->renderForm();
            } else {
                $this->processSaveModule();
                return $this->html . $this->renderForm();
            }
        } else {
            $this->html .= $this->renderForm();
            return $this->html;
        }
    }

    public function processSaveModule()
    {
        $footerpayment = new FooterPayment(Tools::getValue('id_footerpayment', 1));
        $languages = Language::getLanguages(false);
        $text = array();
        foreach ($languages as $lang) {
            $text[$lang['id_lang']] = Tools::getValue('text_'.$lang['id_lang']);
        }
        $footerpayment->text = $text;

        if (Shop::isFeatureActive() && !$footerpayment->id_shop) {
            $saved = true;
            foreach ($shop_ids as $id_shop) {
                $footerpayment->id_shop = $id_shop;
                $saved &= $footerpayment->add();
            }
        } else {
            $saved = $footerpayment->save();
        }

        if ($saved) {
            Tools::clearCache();
        } else {
            $this->html .=
                '<div class="alert alert-danger conf error">'
                    .$this->trans('An error occurred on saving.', array(), 'Admin.Notifications.Error')
                .'</div>';
        }

        return $saved;
    }

    protected function renderForm()
    {
        $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');

        $fields_form = array(
            'tinymce' => true,
            'legend' => array(
                'title' => $this->trans('Settings', array(), 'Modules.FooterPayment.Admin'),
            ),
            'input' => array(
                'id_footerpayment' => array(
                    'type' => 'hidden',
                    'name' => 'id_footerpayment'
                ),
                'content' => array(
                    'type' => 'textarea',
                    'label' => $this->trans('Custom texts', array(), 'Modules.FooterPayment.Admin'),
                    'lang' => true,
                    'name' => 'text',
                    'cols' => 40,
                    'rows' => 10,
                    'class' => 'rte',
                    'autoload_rte' => true,
                ),
            ),
            'submit' => array(
                'title' => $this->trans('Save', array(), 'Admin.Actions'),
            )
        );

        if (Shop::isFeatureActive() && Tools::getValue('id_footerpayment') == false) {
            $fields_form['input'][] = array(
                'type' => 'shop',
                'label' => $this->trans('Shop association', array(), 'Admin.Global'),
                'name' => 'checkBoxShopAsso_theme'
            );
        }


        $helper = new HelperForm();
        $helper->module = $this;
        $helper->name_controller = 'mt_footerpayment';
        $helper->identifier = $this->identifier;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        foreach (Language::getLanguages(false) as $lang) {
            $helper->languages[] = array(
                'id_lang' => $lang['id_lang'],
                'iso_code' => $lang['iso_code'],
                'name' => $lang['name'],
                'is_default' => ($default_lang == $lang['id_lang'] ? 1 : 0)
            );
        }

        $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;
        $helper->default_form_language = $default_lang;
        $helper->allow_employee_form_lang = $default_lang;
        $helper->toolbar_scroll = true;
        $helper->title = $this->displayName;
        $helper->submit_action = 'submitModule';

        $helper->fields_value = $this->getFormValues();

        return $helper->generateForm(array(array('form' => $fields_form)));
    }

    public function getFormValues()
    {
        $fields_value = array();
        $id_footerpayment = 1;

        foreach (Language::getLanguages(false) as $lang) {
            $footerpayment = new FooterPayment((int)$id_footerpayment);
            $fields_value['text'][(int)$lang['id_lang']] = $footerpayment->text[(int)$lang['id_lang']];
        }

        $fields_value['id_footerpayment'] = $id_footerpayment;

        return $fields_value;
    }

    public function renderWidget($hookName = null, array $configuration = [])
    {
        $this->smarty->assign($this->getWidgetVariables($hookName, $configuration));

        return $this->fetch($this->templateFile, $this->getCacheId('mt_footerpayment'));
    }
    public function getWidgetVariables($hookName = null, array $configuration = [])
    {
        $sql = 'SELECT r.`id_footerpayment`, r.`id_shop`, rl.`text`
            FROM `'._DB_PREFIX_.'mt_footerpayment` r
            LEFT JOIN `'._DB_PREFIX_.'mt_footerpayment_lang` rl ON (r.`id_footerpayment` = rl.`id_footerpayment`)
            WHERE `id_lang` = '.(int)$this->context->language->id.' AND  `id_shop` = '.(int)$this->context->shop->id;

        return [
            'footerpayment' => Db::getInstance()->getRow($sql),
        ];
    }

    public function installFixtures()
    {
        $return = true;
        $tab_texts = array(
            array(
                
                'text' => '<div class="footer-payment">
                                <h6 class="widget-title">Payment</h6>
                                <a href="#"><img src="'._MODULE_DIR_.$this->name.'/img/payment.png'.'" alt="payment" /></a>
                            </div>'
            ),
        );

        $shops_ids = Shop::getShops(true, null, true);

        foreach ($tab_texts as $tab) {
            $footerpayment = new FooterPayment();
            foreach (Language::getLanguages(false) as $lang) {
                $footerpayment->text[$lang['id_lang']] = $tab['text'];
            }
            foreach ($shops_ids as $id_shop) {
                $footerpayment->id_shop = $id_shop;
                $return &= $footerpayment->add();
            }
        }

        return $return;
    }
}