<?php

if (!defined('_PS_VERSION_')) {
	exit;
}

use PrestaShop\PrestaShop\Core\Module\WidgetInterface;

require_once _PS_MODULE_DIR_.'mt_customhtml/CustomHtml.php';

class Mt_Customhtml extends Module implements WidgetInterface
{
	protected $html = '';
	private $templateFile;

	public function __construct()
	{
		$this->name = 'mt_customhtml';
		$this->tab = 'front_office_features';
		$this->version = '1.0.0';
		$this->author = 'Mahardhi';
		$this->need_instance = 0;
		$this->secure_key = Tools::encrypt($this->name);
		$this->bootstrap = true;
		parent::__construct();

		$this->displayName = $this->trans('Custom Html Blocks', array(), 'Modules.Customhtml.Admin');
		$this->description = $this->trans('Adds custom information block in your store.', array(), 'Modules.Customhtml.Admin');
		$this->ps_versions_compliancy = array('min' => '1.7.4.0', 'max' => _PS_VERSION_);

		$this->templateFile = 'module:mt_customhtml/views/templates/hook/CustomHtml.tpl';
	}

	public function install()
	{
		return  parent::install() &&
			$this->installDB() &&
			$this->registerHook('displayhome') &&
			$this->installFixtures();
	}

	public function installDB()
	{
		$return = true;
		$return &= Db::getInstance()->execute('
			CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'mt_customhtml` (
				`id_customhtml` INT UNSIGNED NOT NULL AUTO_INCREMENT,
				`id_shop` int(10) unsigned DEFAULT NULL,
				PRIMARY KEY (`id_customhtml`)
				) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8 ;'
		);

		$return &= Db::getInstance()->execute('
			CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'mt_customhtml_lang` (
				`id_customhtml` INT UNSIGNED NOT NULL,
				`id_lang` int(10) unsigned NOT NULL ,
				`text` text NOT NULL,
				PRIMARY KEY (`id_customhtml`, `id_lang`)
				) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8 ;'
		);

		return $return;
	}

	public function uninstall()
	{
		return parent::uninstall() && $this->uninstallDB();
	}

	public function uninstallDB($drop_table = true)
	{
		$ret = true;
			if ($drop_table) {
				$ret &=  Db::getInstance()->execute('DROP TABLE IF EXISTS `'._DB_PREFIX_.'mt_customhtml`') && Db::getInstance()->execute('DROP TABLE IF EXISTS `'._DB_PREFIX_.'mt_customhtml_lang`');
			}

		return $ret;
	}

	public function getContent()
	{
		if (Tools::isSubmit('submitModule')) {
			if (!Tools::getValue('text_'.(int)Configuration::get('PS_LANG_DEFAULT'), false)) {
				return $this->html . $this->displayError($this->trans('Please fill out all fields.', array(), 'Admin.Notifications.Error')) . $this->renderForm();
			}
			else {
				$this->processSaveModule();
				return $this->html . $this->renderForm();
			}
		}
		else {
			$this->html .= $this->renderForm();
			return $this->html;
		}
	}

	public function processSaveModule()
	{
		$customhtml = new CustomHtml(Tools::getValue('id_customhtml', 1));
		$languages = Language::getLanguages(false);
		$text = array();
		foreach ($languages as $lang) {
			$text[$lang['id_lang']] = Tools::getValue('text_'.$lang['id_lang']);
		}
		$customhtml->text = $text;

		if (Shop::isFeatureActive() && !$customhtml->id_shop) {
			$saved = true;
			foreach ($shop_ids as $id_shop) {
				$customhtml->id_shop = $id_shop;
				$saved &= $customhtml->add();
			}
		}
		else {
			$saved = $customhtml->save();
		}

		if ($saved) {
			Tools::clearCache();
		}
		else {
			$this->html .=
			'<div class="alert alert-danger conf error">'
				.$this->trans('An error occurred on saving.', array(), 'Admin.Notifications.Error')
			.'</div>';
		}

		return $saved;
	}

	protected function renderForm()
	{
		$default_lang = (int)Configuration::get('PS_LANG_DEFAULT');

		$fields_form = array(
			'tinymce' => true,
			'legend' => array(
				'title' => $this->trans('Settings', array(), 'Modules.Customhtml.Admin'),
			),
			'input' => array(
				'id_customhtml' => array(
					'type' => 'hidden',
					'name' => 'id_customhtml'
				),
				'content' => array(
					'type' => 'textarea',
					'label' => $this->trans('Custom texts', array(), 'Modules.Customhtml.Admin'),
					'lang' => true,
					'name' => 'text',
					'cols' => 40,
					'rows' => 10,
					'class' => 'rte',
					'autoload_rte' => true,
				),
			),
			'submit' => array(
				'title' => $this->trans('Save', array(), 'Admin.Actions'),
			)
		);

		if (Shop::isFeatureActive() && Tools::getValue('id_customhtml') == false) {
			$fields_form['input'][] = array(
				'type' => 'shop',
				'label' => $this->trans('Shop association', array(), 'Admin.Global'),
				'name' => 'checkBoxShopAsso_theme'
			);
		}


		$helper = new HelperForm();
		$helper->module = $this;
		$helper->name_controller = 'mt_customhtml';
		$helper->identifier = $this->identifier;
		$helper->token = Tools::getAdminTokenLite('AdminModules');
		foreach (Language::getLanguages(false) as $lang) {
			$helper->languages[] = array(
				'id_lang' => $lang['id_lang'],
				'iso_code' => $lang['iso_code'],
				'name' => $lang['name'],
				'is_default' => ($default_lang == $lang['id_lang'] ? 1 : 0)
			);
		}

		$helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;
		$helper->default_form_language = $default_lang;
		$helper->allow_employee_form_lang = $default_lang;
		$helper->toolbar_scroll = true;
		$helper->title = $this->displayName;
		$helper->submit_action = 'submitModule';

		$helper->fields_value = $this->getFormValues();

		return $helper->generateForm(array(array('form' => $fields_form)));
	}

	public function getFormValues()
	{
		$fields_value = array();
		$id_customhtml = 1;

		foreach (Language::getLanguages(false) as $lang) {
			$customhtml = new CustomHtml((int)$id_customhtml);
			$fields_value['text'][(int)$lang['id_lang']] = $customhtml->text[(int)$lang['id_lang']];
		}

		$fields_value['id_customhtml'] = $id_customhtml;

		return $fields_value;
	}

	public function renderWidget($hookName = null, array $configuration = [])
	{
		$this->smarty->assign($this->getWidgetVariables($hookName, $configuration));

		return $this->fetch($this->templateFile, $this->getCacheId('mt_customhtml'));
	}

	public function getWidgetVariables($hookName = null, array $configuration = [])
	{
		$sql = 'SELECT r.`id_customhtml`, r.`id_shop`, rl.`text`
			FROM `'._DB_PREFIX_.'mt_customhtml` r
			LEFT JOIN `'._DB_PREFIX_.'mt_customhtml_lang` rl ON (r.`id_customhtml` = rl.`id_customhtml`)
			WHERE `id_lang` = '.(int)$this->context->language->id.' AND  `id_shop` = '.(int)$this->context->shop->id;

		return [
			'customhtml' => Db::getInstance()->getRow($sql),
		];
	}

	public function installFixtures()
	{
		$return = true;
		$tab_texts = array(
			array(
				'text' => '<div class="promo-banner-inner">
                                <div class="banner1 col-xs-4">
                                    <div class="promo-banner">
                                        <a href="#">
                                            <img src="'._MODULE_DIR_.$this->name.'/img/banner-1.jpg" alt="Banner1">
                                        </a>
                                        <div class="promo-text-wrapper">
                                            <div class="promo-desc">Swimwear</div>
                                            <div class="promo-text">
                                                <h3 class="promo-title">Men\'s Collection</h3>
                                                <button type="button" class="promo-btn btn btn-primary">SHOP NOW</button>
                                            </div>
                                            <div class="promo-inner-img">
                                                <a href="#">
                                                    <img src="'._MODULE_DIR_.$this->name.'/img/banner-01.jpg" alt="Banner01" class="img-circle">
                                                 </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="banner2 col-xs-4">
                                    <div class="promo-banner">
                                        <a href="#">
                                            <img src="'._MODULE_DIR_.$this->name.'/img/banner-2.jpg" alt="Banner2">
                                        </a>
                                        <div class="promo-text-wrapper">
                                            <div class="promo-desc">Swimwear</div>
                                            <div class="promo-text">
                                                <h3 class="promo-title">Women\'s Collection</h3>
                                                <button type="button" class="promo-btn btn btn-primary">SHOP NOW</button>
                                            </div>
                                            <div class="promo-inner-img">
                                                <a href="#">
                                                    <img src="'._MODULE_DIR_.$this->name.'/img/banner-02.jpg" alt="Banner02" class="img-circle">
                                                 </a>
                                            </div>
                                        </div>
                                    </div>
                                </div><div class="banner3 col-xs-4">
                                    <div class="promo-banner">
                                        <a href="#">
                                            <img src="'._MODULE_DIR_.$this->name.'/img/banner-3.jpg" alt="Banner3">
                                        </a>
                                        <div class="promo-text-wrapper">
                                            <div class="promo-desc">Swimwear</div>
                                            <div class="promo-text">
                                                <h3 class="promo-title">Kid\'s Collection</h3>
                                                <button type="button" class="promo-btn btn btn-primary">SHOP NOW</button>
                                            </div>
                                            <div class="promo-inner-img">
                                                <a href="#">
                                                    <img src="'._MODULE_DIR_.$this->name.'/img/banner-03.jpg" alt="Banner03" class="img-circle">
                                                 </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>'
			),
		);

		$shops_ids = Shop::getShops(true, null, true);

		foreach ($tab_texts as $tab) {
			$customhtml = new CustomHtml();
			foreach (Language::getLanguages(false) as $lang) {
				$customhtml->text[$lang['id_lang']] = $tab['text'];
			}
			foreach ($shops_ids as $id_shop) {
				$customhtml->id_shop = $id_shop;
				$return &= $customhtml->add();
			}
		}
		return $return;
	}
}