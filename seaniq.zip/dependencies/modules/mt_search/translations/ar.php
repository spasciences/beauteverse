<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mt_search}prestashop>mt_search_2a37324bb4c331c859044121df3f576b'] = 'بحث...';
