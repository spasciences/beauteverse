<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mt_search}prestashop>mt_search_9316fec5d3723608bb74aa5d568306fb'] = 'Sie müssen mindestens drei Zeichen eingeben';
$_MODULE['<{mt_search}prestashop>mt_search_b9af8635591dc44009ccd8e5389722ec'] = 'Keine Produkte gefunden';
$_MODULE['<{mt_search}prestashop>mt_search_13348442cc6a27032d2b4aa28b75a5d3'] = 'Suche';
$_MODULE['<{mt_search}prestashop>mt_search_2a37324bb4c331c859044121df3f576b'] = 'Suche...';
