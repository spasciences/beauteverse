<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\PrestaShop\Core\Module\WidgetInterface;

class Mt_Search extends Module implements WidgetInterface
{
	private $templateFile;
    protected $default_count = 3;
    protected $default_img = 1;
    protected $default_name = 1;
    protected $default_price = 1;
	
	public function __construct()
    {
    	$this->name = 'mt_search';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'Mahardhi';
        $this->need_instance = 0;
        
        $this->bootstrap = true;
        parent::__construct();

        $this->displayName = $this->trans('Ajax Search block', array(), 'Modules.Search.Admin');
        $this->description = $this->trans('Adds search block showing results with product information.', array(), 'Modules.Search.Admin');
        $this->ps_versions_compliancy = array('min' => '1.7.4.0', 'max' => _PS_VERSION_);
        
        $this->character_limit = $this->trans('You must enter at least three characters', array(), 'Modules.Search.Admin');
        $this->no_product = $this->trans('No products found', array(), 'Modules.Search.Admin');
        $this->templateFile = 'module:mt_search/views/templates/hook/mt_search.tpl';
    }

    /**
     * @see Module::install()
     */
    public function install()
    {
    	return (parent::install()
            && Configuration::updateValue('MT_SEARCH_COUNT', $this->default_count)
            && Configuration::updateValue('MT_SEARCH_IMAGE', $this->default_img)
            && Configuration::updateValue('MT_SEARCH_NAME', $this->default_name)
            && Configuration::updateValue('MT_SEARCH_PRICE', $this->default_price)
            && $this->registerHook('displayNav3'));
    }

    /**
     * @see Module::uninstall()
     */
    public function uninstall()
    {
        return (Configuration::deleteByName('MT_SEARCH_COUNT')
            && Configuration::deleteByName('MT_SEARCH_IMAGE')
            && Configuration::deleteByName('MT_SEARCH_NAME')
            && Configuration::deleteByName('MT_SEARCH_PRICE')
            && parent::uninstall() );
    }

    public function getContent()
    {
        $output = '';
        $result = '';

        if (Tools::isSubmit('submitModule')) {
            if (!$result = $this->preValidateForm()) {
                Configuration::updateValue('MT_SEARCH_COUNT', Tools::getValue('MT_SEARCH_COUNT'));
                Configuration::updateValue('MT_SEARCH_IMAGE', Tools::getValue('MT_SEARCH_IMAGE'));
                Configuration::updateValue('MT_SEARCH_NAME', Tools::getValue('MT_SEARCH_NAME'));
                Configuration::updateValue('MT_SEARCH_PRICE', Tools::getValue('MT_SEARCH_PRICE'));
                $output .= $this->displayConfirmation($this->trans('The settings have been updated.', array(), 'Modules.Search.Admin'));
            } else {
                $output = $result;
                $output .= $this->renderForm();
            }
        }

        if (!$result) {
            $output .= $this->renderForm();
        }

        return $output;
    }

    public function renderForm()
    {
        $fields_form = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->trans('Settings', array(), 'Admin.Global'),
                    'icon' => 'icon-cogs'
                ),
                'input' => array(
                    array(
                        'type' => 'text',
                        'label' => $this->trans('Maximum number of products in search result', array(), 'Admin.Global'),
                        'name' => 'MT_SEARCH_COUNT',
                        'required' => true,
                        'class' => 'fixed-width-sm'
                    ),
                    array(
                        'type' => 'switch',
                        'label' => $this->trans('Show Product Image', array(), 'Admin.Global'),
                        'name' => 'MT_SEARCH_IMAGE',
                        'values' => array(
                            array(
                                'id' => 'active_on',
                                'value' => 1,
                                'label' => $this->trans('Enabled', array(), 'Admin.Global')
                            ),
                            array(
                                'id' => 'active_off',
                                'value' => 0,
                                'label' => $this->trans('Disabled', array(), 'Admin.Global')
                            )
                        ),
                    ),
                    array(
                        'type' => 'switch',
                        'label' => $this->trans('Show Product Name', array(), 'Admin.Global'),
                        'name' => 'MT_SEARCH_NAME',
                        'values' => array(
                            array(
                                'id' => 'active_on',
                                'value' => 1,
                                'label' => $this->trans('Enabled', array(), 'Admin.Global')
                            ),
                            array(
                                'id' => 'active_off',
                                'value' => 0,
                                'label' => $this->trans('Disabled', array(), 'Admin.Global')
                            )
                        ),
                    ),
                    array(
                        'type' => 'switch',
                        'label' => $this->trans('Show Product Price', array(), 'Admin.Global'),
                        'name' => 'MT_SEARCH_PRICE',
                        'values' => array(
                            array(
                                'id' => 'active_on',
                                'value' => 1,
                                'label' => $this->trans('Enabled', array(), 'Admin.Global')
                            ),
                            array(
                                'id' => 'active_off',
                                'value' => 0,
                                'label' => $this->trans('Disabled', array(), 'Admin.Global')
                            )
                        ),
                    ),
                ),
                'submit' => array(
                    'title' => $this->trans('Save', array(), 'Admin.Actions'),
                )
            ),
        );

        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->submit_action = 'submitModule';
        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFieldsValues(),
        );
        return $helper->generateForm(array($fields_form));
    }

    public function getConfigFieldsValues()
    {
        return array(
            'MT_SEARCH_COUNT' => Tools::getValue('MT_SEARCH_COUNT', Configuration::get('MT_SEARCH_COUNT')),
            'MT_SEARCH_IMAGE' => Tools::getValue('MT_SEARCH_IMAGE', Configuration::get('MT_SEARCH_IMAGE')),
            'MT_SEARCH_NAME'  => Tools::getValue('MT_SEARCH_NAME', Configuration::get('MT_SEARCH_NAME')),
            'MT_SEARCH_PRICE' => Tools::getValue('MT_SEARCH_PRICE', Configuration::get('MT_SEARCH_PRICE'))
        );
    }

    protected function preValidateForm()
    {
        $errors = array();

        if (Tools::isEmpty(Tools::getValue('MT_SEARCH_COUNT'))) {
            $errors[] = $this->trans('Product count is required and should be a number.', array(), 'Admin.Notifications.Error');
        } else {
            if (!Validate::isUnsignedInt(Tools::getValue('MT_SEARCH_COUNT'))) {
                $errors[] = $this->trans('Product count should be a number', array(), 'Admin.Notifications.Error');
            }
        }
        return false;
    }

    public function renderWidget($hookName, array $configuration = [])
    {
        $this->smarty->assign($this->getWidgetVariables($hookName, $configuration));
        return $this->fetch($this->templateFile);
    }

    public function getWidgetVariables($hookName, array $configuration = [])
    {
        return [
            'search_ajax_url' => $this->context->link->getPageLink('search', null, null, null, false, null, true),
        ];
    }
}