<?php

require_once('../../config/config.inc.php');
require_once('../../init.php');
require_once(dirname(__FILE__).'/mt_search.php');

$mt_search = new Mt_Search();
$result_products = array();
$products = array();
$mt_search_key = Tools::getValue('search_key');
$context = Context::getContext();
$count = 0;
$product_link = $context->link;

if (Tools::strlen($mt_search_key) >= 0) {
    $products = Product::searchByName($context->language->id, $mt_search_key);
    $total_products = count($products);
    if ($total_products) {
        for ($i = 0; $i < $total_products; $i++) {
            if (($products[$i]['name']) && ($products[$i]['active'])) {
                $images = Image::getImages($context->language->id, $products[$i]['id_product']);
                $product = new Product($products[$i]['id_product']);
                $products[$i]['link'] = $product_link->getProductLink($products[$i]['id_product'], $product->link_rewrite[1], $product->id_category_default, $product->ean13);
                $products[$i]['link_rewrite'] = $product->link_rewrite[1];
                $products[$i]['id_image'] = $images[0]['id_image'];
                $products[$i]['price'] = Tools::displayPrice(Tools::convertPrice($products[$i]['price_tax_incl'], $context->currency), $context->currency);
                if ($count < Configuration::get('MT_SEARCH_COUNT')) {
                    $result_products[] = $products[$i];
                    $count ++;
                } else {
                    break;
                }
            }
        }
    }

    $context->smarty->assign(array(
        'enable_image' => Configuration::get('MT_SEARCH_IMAGE'),
        'enable_name' => Configuration::get('MT_SEARCH_NAME'),
        'enable_price' => Configuration::get('MT_SEARCH_PRICE'),
        'search_alert' => $mt_search->no_product,
        'link' => $context->link,
        'products' => $result_products,
    ));

    $context->smarty->display(dirname(__FILE__).'/views/templates/hook/searchpopup.tpl');
} else {
    echo '<div class="search_popup_inner">'.$mt_search->character_limit.'</div>';
}