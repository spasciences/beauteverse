<?php
require_once(dirname(__FILE__).'/../../config/config.inc.php');
require_once(dirname(__FILE__).'/../../init.php');
include(dirname(__FILE__).'/mt_newsletterpopup.php');
$newsletter_popup = new Mt_NewsletterPopup();
	echo $newsletter_popup->newsletterRegistration(Tools::getValue('email'));
