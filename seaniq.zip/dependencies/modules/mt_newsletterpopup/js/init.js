(function ($) {
    "use strict";
		
	$(".send-reqest").on('click',function(){
		var email = $("#newsletter-input").val();
		$.ajax({
			type: "POST",
			headers: { "cache-control": "no-cache" },
			async: false,
			url: newsletter_path,
			data: "name=newsletter&email="+email,
			dataType: "jsonp",
			jsonp: 'callback',
			success: function(data) {
				if (data){
					$(".send-response").html(data);
				}
			}
		});
	});

	$('#newsletter-input').keypress(function(event){
	  var keycode = (event.keyCode ? event.keyCode : event.which);
	  if (keycode == '13') {
		var email = $("#newsletter-input").val();
		$.ajax({
			type: "POST",
			headers: { "cache-control": "no-cache" },
			async: false,
			url: newsletter_path,
			data: "name=newsletter&email="+email,
			dataType: "jsonp",
			jsonp: 'callback',
			success: function(data) {
				if (data){
					$(".send-response").html(data);					
				}
			}
		});
		event.preventDefault();
	  }
	});

	$('#newsletter_popup_show_again').on('change',function(){
	    if($(this).is(':checked')){
			$.cookie("newsletterpopup", "true",{'expires':1,'path':'/'});  
	    }else{
	    	$.cookie("newsletterpopup", "false",{'expires':-1,'path':'/'});
	    }
	});

})(jQuery);