<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mt_newsletterpopup}prestashop>mt_newsletterpopup_7b87b5bd4cf77cc081aeb01a24f71c03'] = 'Geben Sie hier die E-Mail-Adresse ein';
$_MODULE['<{mt_newsletterpopup}prestashop>mt_newsletterpopup_b26917587d98330d93f87808fc9d7267'] = 'Abonnieren';
$_MODULE['<{mt_newsletterpopup}prestashop>mt_newsletterpopup_48b2f995a0de33911345dcabe94ae110'] = 'Zeige dieses Popup nicht mehr!';
$_MODULE['<{mt_newsletterpopup}prestashop>configure_709b7b65921f85f03898ebf6baf842e5'] = 'Popup-Newsletter-Modul mit Newsletter-Abonnement';
$_MODULE['<{mt_newsletterpopup}prestashop>configure_8326752b60221a9d5951ee2b00afa5ae'] = 'Sie können es mit dem folgenden Konfigurationsformular konfigurieren.';
$_MODULE['<{mt_newsletterpopup}prestashop>configure_0e4335d6b1bad4469be0f83ad295f492'] = 'Das Blocknewsletter-Modul muss installiert sein, um die Newsletter-Formularoption verwenden zu können';
$_MODULE['<{mt_newsletterpopup}prestashop>configure_e2821f69bf9ac0c15c087fdc80ae1d6a'] = 'Steigern Sie Ihre Newsletter-Abonnements mit einem Popup-Fenster!';
$_MODULE['<{mt_newsletterpopup}prestashop>form_99e48474abc8b7eba786e18415980115'] = 'Hintergrundbildauswahl';
