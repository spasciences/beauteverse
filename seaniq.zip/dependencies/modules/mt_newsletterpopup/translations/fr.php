<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mt_newsletterpopup}prestashop>mt_newsletterpopup_7b87b5bd4cf77cc081aeb01a24f71c03'] = 'Entrez votre adresse e-mail ici';
$_MODULE['<{mt_newsletterpopup}prestashop>mt_newsletterpopup_b26917587d98330d93f87808fc9d7267'] = 'Souscrire';
$_MODULE['<{mt_newsletterpopup}prestashop>mt_newsletterpopup_48b2f995a0de33911345dcabe94ae110'] = 'Ne plus afficher ce popup!';
$_MODULE['<{mt_newsletterpopup}prestashop>configure_709b7b65921f85f03898ebf6baf842e5'] = 'Module de newsletter pop-up avec abonnement à la newsletter';
$_MODULE['<{mt_newsletterpopup}prestashop>configure_8326752b60221a9d5951ee2b00afa5ae'] = 'Vous pouvez le configurer à l\'aide du formulaire de configuration suivant.';
$_MODULE['<{mt_newsletterpopup}prestashop>configure_0e4335d6b1bad4469be0f83ad295f492'] = 'le module blocknewsletter doit être installé pour utiliser l\'option formulaire de newsletter';
$_MODULE['<{mt_newsletterpopup}prestashop>configure_e2821f69bf9ac0c15c087fdc80ae1d6a'] = 'Boostez vos abonnements aux newsletters avec une fenêtre popup!';
$_MODULE['<{mt_newsletterpopup}prestashop>form_99e48474abc8b7eba786e18415980115'] = 'Sélecteur d\'images d\'arrière-plan';
