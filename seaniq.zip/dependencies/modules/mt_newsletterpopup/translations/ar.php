<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mt_newsletterpopup}prestashop>mt_newsletterpopup_7b87b5bd4cf77cc081aeb01a24f71c03'] = 'أدخل عنوان البريد الإلكتروني هنا';
$_MODULE['<{mt_newsletterpopup}prestashop>mt_newsletterpopup_b26917587d98330d93f87808fc9d7267'] = 'الإشتراك';
$_MODULE['<{mt_newsletterpopup}prestashop>mt_newsletterpopup_48b2f995a0de33911345dcabe94ae110'] = 'لا تظهر هذه النافذة المنبثقة مرة أخرى!';
